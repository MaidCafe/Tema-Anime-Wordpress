<?php 

//======================
	//Admin menu 
//======================


function megumi_add_admin_page() {
	add_menu_page( 'Megumi Theme Options', 'Nyaa Setting', 'manage_options', 'megumi_kato', 'megumi_theme_create_page',  get_template_directory_uri() . '/img/sunset-icon.png', 120 );
	//add Submenu page
	add_submenu_page( 'megumi_kato', 'Kato Theme Options', 'Setting', 'manage_options', 'megumi_kato', 'megumi_theme_create_page' );

}

add_action( 'admin_menu', 'megumi_add_admin_page' );

//Activate custom settings
add_action( 'admin_init', 'megumi_custom_settings' );

function megumi_custom_settings() {

//CPT =custom Post type
	register_setting( 'Kato-post-type', 'custom_batch' );
	register_setting( 'Kato-post-type', 'custom_ost' );
	register_setting( 'Kato-post-type', 'custom_background' );
	
	add_settings_section( 'sunset-theme-options', 'Theme Options', 'sunset_theme_options', 'megumi_postype' );
	
	
	add_settings_section( 'sunset-theme-options', 'Theme Options', 'kato_metabox_options', 'megumi_katobox' );


	register_setting( 'kato-metabox-act', 'metabox_mp4' );
	
	add_settings_field( 'streaming-sub', 'Metabox MP4 360p-480p-MP4HD-FullHD', 'kato_metabox_mp4', 'megumi_katobox', 'sunset-theme-options' );

	//setting page
	 // MAIN
        // MISC
        register_setting( 'sachi-config', 'config_infoweb' );
        register_setting( 'sachi-config', 'config_aboutweb' );
    // DOWNLOAD
        // mp4 link
        register_setting( 'sachi-config', 'config_mp4_name1' );
        register_setting( 'sachi-config', 'config_mp4_name2' );
        register_setting( 'sachi-config', 'config_mp4_name3' );
        register_setting( 'sachi-config', 'config_mp4_name4' );
    
}

//
function kato_admin_meta() {
	echo 'Ubah Pengaturan Kato Theme dan lainya disini';
}

//create page/sbpage
function megumi_theme_create_page() {
	require_once( get_template_directory() . '/inc/templates/kato-admin.php' );
}

