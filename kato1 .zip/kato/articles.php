<div class="recent-post col-md-4 col-sm-4 col-xs-6">
<div class="recent-thumb">
<div class="recent-view"><i class="fa fa-eye"></i><?php echo getCrunchifyPostViews(get_the_ID());?></div>
<div class="recent-eps"><?php echo get_post_meta($post->ID, 'dbt_episodnime', true);?></div>
<?php
$valky = get_the_term_list( $post->ID , 'idnum' );
    $args = array(
        'post_type' => 'anime',
        'post__not_in' => array( get_the_ID() ),
        'posts_per_page' => 1,
        'idnam'     => $valky,
        'meta_query' => array(
                    array(
                    
                        )
                    )
    );
    $query = new WP_Query( $args );

?>  
<?php if( $query->have_posts() ) : while( $query->have_posts() ) : $query->the_post(); ?>
<div class="recent-stat"><?php echo get_the_term_list( $post->ID, 'status', '', ', ', '' ); ?></div>
<?php endwhile; endif; wp_reset_postdata(); ?>
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
<?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(320, 320, true)); }else { echo '<img style="width:350!important;max-width:inherit;" src="https://animesearch.net/wp-content/uploads/2017/03/bg-player.jpg"></img>'; } ?>
<h2 class='recent-title'><?php the_title(); ?></h2>

</a>
<div class="p">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<?php
$valky = get_the_term_list( $post->ID , 'idnum' );
    $args = array(
        'post_type' => 'anime',
        'post__not_in' => array( get_the_ID() ),
        'posts_per_page' => 1,
        'idnam'     => $valky,
        'meta_query' => array(
                    array(
                    
                        )
                    )
    );
    $query = new WP_Query( $args );

?>  
<?php if( $query->have_posts() ) : while( $query->have_posts() ) : $query->the_post(); ?>
<p>
<?php echo get_the_term_list( $post->ID, 'rating', '<p><b>Rating </b>: ', ', ', '</p>' ); ?>
</p>
</div>
<?php endwhile; endif; wp_reset_postdata(); ?>
</div>
</div>