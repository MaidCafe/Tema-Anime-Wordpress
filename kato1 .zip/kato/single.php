<?php get_header(); ?>
<div id="kasumigaoka">
<div id="antblock" class="row-flex cl"><div class="left"><div class="clear"></div><div class="right"></div></div></div>
<div class="clear"></div>
<div class="katobody col-md-8 col-sm-8 col-xs-12" id="main-wrap">
<div class="bodo">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class='titler'>
<h1 class="ttl"><?php the_title(); ?></h1>
<div class='kategori'>
<?php
          setCrunchifyPostViews(get_the_ID());
?>
Released on <?php the_time('jS F, Y'); ?> , <i class='fa fa-eye'></i></b> <?php
          echo getCrunchifyPostViews(get_the_ID());
?> 
</div>
</div>
<div id='switch'>
<span class='lightSwitcher' id='checkbox'>

<label data-off='OFF' data-on='ON'></label>
</span>
</div>
<div class='outer' ng-app='tabs'>
  <div class='tabs' ng-controller='shift_tabs as shift'>
    <div class='tab-buttons' ng-init='shift.makeShift(1)'>
      <button ng-click='shift.makeShift(1)' ng-class='{active:shift.isActive(1)}'>Google</button>
      <button ng-click='shift.makeShift(2)' ng-class='{active:shift.isActive(2)}'>Openload</button>
      <button ng-click='shift.makeShift(3)' ng-class='{active:shift.isActive(3)}'>MP4Upload</button>
    </div>
    <div class='tab-content'>
      <div ng-show='shift.isActive(1)'>
<iframe  src="<?php echo get_post_meta($post->ID, 'stream_url1', true);?>" scrolling="no" frameborder="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe></div>
      <div ng-show='shift.isActive(2)'><iframe  src="<?php echo get_post_meta($post->ID, 'stream_url2', true);?>" scrolling="no" frameborder="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe></div>
      <div ng-show='shift.isActive(3)'><iframe  src="<?php echo get_post_meta($post->ID, 'stream_url3', true);?>" scrolling="no" frameborder="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe></div>
    </div>
  </div>
</div>
<div class="clear"></div>
<?php echo sagirih_pagination() ?>
<div class="clear"></div>
<hr />
<?php echo sagirih_info() ?>
</div>
<div class="clear"></div>
<hr />
<div class='titler'>
<center>
<h1 class="ttl">Link Download</h1>
<i class='fa fa-download'></i>
</center>
<div class='kategori'>
<center>
Mohon Maaf Jika Link Reupload Googledrive terkena limit bisa gunakan gamerse dan miror lainya
</center>
<center>
Credit or Subbed by : Tertera dalam Video <br>
Samehadaku, Naruciha, Tiramisub, Awsub, DLL
</center>
</div>
</div>
<div class="clear"></div>
<div class="katodl">
<div class="katotl"><h4><?php the_title(); ?>  480p MKV</h4></div>
<div class="katourl">
<h5><?php 
// LINK 1
          if(!empty(get_post_meta(get_the_ID(), 'kato_url1', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kato_url1', true).'" target="_blank">',get_option('config_480p_name1')?:'Solidfiles','</a> | ';
          }else{echo '<del>',get_option('config_480p_name1')?:'Solidfiles','</del> | ';}
          // LINK 2
          if(!empty(get_post_meta(get_the_ID(), 'kato_url2', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kato_url2', true).'" target="_blank">',get_option('config_480p_name2')?:'Savefile','</a> | ';
          }else{echo '<del>',get_option('config_480p_name2')?:'Savefile','</del> | ';}
          // LINK 3
          if(!empty(get_post_meta(get_the_ID(), 'kato_url3', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kato_url3', true).'" target="_blank">',get_option('config_480p_name3')?:'Zippyshare','</a> | ';
          }else{echo '<del>',get_option('config_480p_name3')?:'Zippyshare','</del> | ';}
          // LINK 4
          if(!empty(get_post_meta(get_the_ID(), 'kato_url4', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kato_url4', true).'" target="_blank">',get_option('config_480p_name4')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_480p_name4')?:'Mirrorcreator','</del> | ';}
          // LINK 5
          if(!empty(get_post_meta(get_the_ID(), 'kato_url5', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kato_url5', true).'" target="_blank">',get_option('config_480p_name5')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_480p_name5')?:'Mirrorcreator','</del> | ';}
          // LINK 6
          if(!empty(get_post_meta(get_the_ID(), 'kato_url6', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kato_url6', true).'" target="_blank">',get_option('config_480p_name6')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_480p_name6')?:'Mirrorcreator','</del> | ';}
          ?>
</h5>
</div>
<div class="katotl"><h4><?php the_title(); ?>  720p MKV</h4></div>
<div class="katourl">
<h5><?php 
// LINK 1
          if(!empty(get_post_meta(get_the_ID(), 'megumi_url1', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'megumi_url1', true).'" target="_blank">',get_option('config_720p_name1')?:'Solidfiles','</a> | ';
          }else{echo '<del>',get_option('config_720p_name1')?:'Solidfiles','</del> | ';}
          // LINK 2
          if(!empty(get_post_meta(get_the_ID(), 'megumi_url2', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'megumi_url2', true).'" target="_blank">',get_option('config_720p_name2')?:'Savefile','</a> | ';
          }else{echo '<del>',get_option('config_720p_name2')?:'Savefile','</del> | ';}
          // LINK 3
          if(!empty(get_post_meta(get_the_ID(), 'megumi_url3', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'megumi_url3', true).'" target="_blank">',get_option('config_720p_name3')?:'Zippyshare','</a> | ';
          }else{echo '<del>',get_option('config_720p_name3')?:'Zippyshare','</del> | ';}
          // LINK 4
          if(!empty(get_post_meta(get_the_ID(), 'megumi_url4', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'megumi_url4', true).'" target="_blank">',get_option('config_720p_name4')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_720p_name4')?:'Mirrorcreator','</del> | ';}
          // LINK 5
          if(!empty(get_post_meta(get_the_ID(), 'megumi_url5', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'megumi_url5', true).'" target="_blank">',get_option('config_720p_name5')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_720p_name5')?:'Mirrorcreator','</del> | ';}
          // LINK 6
          if(!empty(get_post_meta(get_the_ID(), 'megumi_url6', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'megumi_url6', true).'" target="_blank">',get_option('config_720p_name6')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_720p_name6')?:'Mirrorcreator','</del> | ';}
          ?>
</h5>
</div>
<div class="katotl"><h4><?php the_title(); ?>  1080p MKV</h4></div>
<div class="katourl">
<h5><?php 
// LINK 1
          if(!empty(get_post_meta(get_the_ID(), 'kasumi_url1', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kasumi_url1', true).'" target="_blank">',get_option('config_1080p_name1')?:'Solidfiles','</a> | ';
          }else{echo '<del>',get_option('config_1080p_name1')?:'Solidfiles','</del> | ';}
          // LINK 2
          if(!empty(get_post_meta(get_the_ID(), 'kasumi_url2', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kasumi_url2', true).'" target="_blank">',get_option('config_1080p_name2')?:'Savefile','</a> | ';
          }else{echo '<del>',get_option('config_1080p_name2')?:'Savefile','</del> | ';}
          // LINK 3
          if(!empty(get_post_meta(get_the_ID(), 'kasumi_url3', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kasumi_url3', true).'" target="_blank">',get_option('config_1080p_name3')?:'Zippyshare','</a> | ';
          }else{echo '<del>',get_option('config_1080p_name3')?:'Zippyshare','</del> | ';}
          // LINK 4
          if(!empty(get_post_meta(get_the_ID(), 'kasumi_url4', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kasumi_url4', true).'" target="_blank">',get_option('config_1080p_name4')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_1080p_name4')?:'Mirrorcreator','</del> | ';}
          // LINK 5
          if(!empty(get_post_meta(get_the_ID(), 'kasumi_url5', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kasumi_url5', true).'" target="_blank">',get_option('config_1080p_name5')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_1080p_name5')?:'Mirrorcreator','</del> | ';}
          // LINK 6
          if(!empty(get_post_meta(get_the_ID(), 'kasumi_url6', true))){
          echo '<a href="'.get_post_meta(get_the_ID(), 'kasumi_url6', true).'" target="_blank">',get_option('config_1080p_name6')?:'Mirrorcreator','</a> | ';
          }else{echo '<del>',get_option('config_1080p_name6')?:'Mirrorcreator','</del> | ';}
          ?>
</h5>
</div>
</div>

<div class="clear"></div>
<!-- START HERE -->
<div class="rindudia">
<table class="rindu-dia row">
<thead>
  <th>Qualitas</th>
  <th>Download</th>
</thead>
<tbody>
<?php $mp4listing_fields = get_post_meta($post->ID, 'mp4listing_fields', true);  if ( $mp4listing_fields ) : ?>
        <?php foreach ( $mp4listing_fields as $field ) { ?>
    <tr>       
            <?php 
             if($field['urls11'] != '');
             if($field['select'] != '');
             if($field['urls22'] != ''); 
?>
       <td class="col-md-7 col-sm-7 col-xs-12 rindu1"><?php echo esc_attr( $field['select'] ); ?></td>
       <td class="col-md-5 col-sm-5 col-xs-12 rindu2"><a class="col-md-6 col-sm-6 col-xs-12" href="<?php echo esc_attr( $field['urls11'] ); ?>"><?php echo get_option('config_mp4_name1')?:'Solidfiles'; ?></a><a class="col-md-6 col-sm-6 col-xs-12" href="<?php echo esc_attr( $field['urls22'] ); ?>"><?php echo get_option('config_mp4_name2')?:'Solidfiles'; ?></a></td>
       
    </tr>
<?php } ?> 
<?php endif; ?>
</tbody>
</table>
</div>

<div class='socialshare row'>
<a class="col-md-4 col-sm-4 col-xs-12 sfb" href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank"><span class="dashicons dashicons-facebook-alt"></span> Facebook</a>
<a class="col-md-4 col-sm-4 col-xs-12 stw" href="http://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank"> <span class="dashicons dashicons-twitter"></span> Twitter</a>
<a class="col-md-4 col-sm-4 col-xs-12 sgp" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank"><span class="dashicons dashicons-googleplus"></span> Google+</a>
</div>
<div class="animeinfo">
<div class="left col-md-7 col-sm-7 col-xs-7">
<?php get_template_part('relatedpost'); ?>
<?php endwhile; endif; ?>
</div>
<div class="right col-md-5 col-sm-5 col-xs-5">

</div>
</div>
<div class="clear"></div>
<div class="commentarea">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php echo get_post_meta($post->ID, "embed", true); ?>
<?php comments_template(); ?>
<?php endwhile; endif; ?>
</div></div>
<!-- END HERE -->
<?php get_template_part('sidebar'); ?>
</div>
<?php get_footer(); ?>