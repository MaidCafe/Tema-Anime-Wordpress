<?php
/*
Template Name: Anime Ongoing
*/

get_header(); ?>

<div id="kasumigaoka">
<div id="antblock"><div class="left"><div class="right"></div></div></div>
<div class="clear"></div>
<div class="katobody col-md-8 col-sm-8 col-xs-12">
<h1 class='arc'>Anime Ongoing</h1>

<div class="animrel-row row row-flex">
		<?php
$myposts = array(
    'showposts' => 16,
    'post_type' => 'anime',
    'orderby' => '',
    'tax_query' => array(
        array(
        'taxonomy' => 'status',
        'field' => 'slug',
        'terms' => 'Ongoing')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
		<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
			<div class="animrel-item col-md-3 col-sm-3 col-xs-4">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
					<div class="animrel-view"><i class="fa fa-eye"></i><?php echo getCrunchifyPostViews(get_the_ID());?></div>
					<?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(160, 230, true)); }?>
					<h2><?php the_title(); ?></h2>
				</a>
<div class="b">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<p>
<?php echo get_the_term_list( $post->ID, 'rating', '<p><b>Rating </b>: ', ', ', '</p>' ); ?>
</p></div>
			</div>
		<?php endwhile; ?>
	</div>
<div class="clear"></div></div>
<?php get_template_part('sidebar'); ?>
</div>
</div>
<?php get_footer(); ?>