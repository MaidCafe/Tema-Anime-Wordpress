<?php
/*
Template Name: Info Anime
*/
get_header();
?>
<div id="kasumigaoka">
<div id="antblock"><div class="left"><div class="right"></div></div></div>
<div class="clear"></div>
<div class="katobody col-md-8 col-sm-8 col-xs-12" id="main-wrap">
<div class="featured2">
<h1 class='arc'><b>Download Anime "<?php the_title(); ?>" Subtitle Indonesia</b></h1>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="fpost">
<div class="embed">
<?php echo get_post_meta($post->ID, "anime", true); ?>
<div class="data">
<div class="imganime"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?></div>
<div class="infonim"><b>Judul</b> : <?php the_title(); ?></div>
<div class="infonim"><?php echo get_the_term_list( $post->ID, 'type', '<p><b>Type </b>: ', '</p>' ); ?></div>
<div class="infonim"><?php echo get_the_term_list( $post->ID, 'status', '<p><b>Status </b>: ', ', ', '</p>' ); ?></div>
<div class="infonim"><?php echo get_the_term_list( $post->ID, 'genre', '<p><b>Genre </b>: ', ', ', '</p>' ); ?></div>
<div class="infonim"><?php echo get_the_term_list( $post->ID, 'episodes', '<p><b>Total Episode </b>: ', '</p>' ); ?></div>
<div class="infonim"><?php echo get_the_term_list( $post->ID, 'rating', '<p><b>Rating </b>: ', ', ', '</p>' ); ?></div>
<div class="infonim"><?php echo get_the_term_list( $post->ID, 'duration', '<p><b>Durasi </b>: ', '</p>' ); ?></div>
<div class="infonim"><?php echo get_the_term_list( $post->ID, 'seasons', '<p><b>Seasons </b>: ', ', ', '</p>' ); ?></div>
</div>
<div id="box"><p><div class="rating">Rating:<?php echo get_the_term_list( $post->ID, 'rating', ' ', ', ', '' ); ?></div></p></div>
<div class="deskripsi"><span class="isi"><?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?></div>
</div>
<div class="judulanime">List Episode "<?php the_title(); ?>" <div class="pdate">Download</div></div>
<?php endwhile; endif; ?>
<?php global $post; ?>
<?php $slug = get_post( $post->ID, "anime", true )->post_name; ?>
<?php $recent = new WP_Query("category_name=$slug&showposts=100"); while($recent->have_posts()) : $recent->the_post(); ?>
<li class="anilist"><div class="tautan"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div><div class="ldate"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">Download</a></div></li>
<?php endwhile; ?>
<?php wp_reset_query(); ?>
</div>
</div>
</div>
<?php include (TEMPLATEPATH . '/sidebar.php'); ?>
</div>
<?php get_footer(); ?></div>