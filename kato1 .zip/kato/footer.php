<?php moe_footer(); ?>
<?php wp_footer(); ?></div>
<div id="katofooter">
<div class="container" id="rapilah">
<div class="footer-column">
<div class="footer-menu">
<div class="side"><h3>About Site</h3>
<div class="textwidget"><p>Kato Megumi Fanshare</p>
<p><a href="https://Batchanime.id">Batchanime.id</a><br /></p>
<p>Created By HandrianD<br /></p>
   <!-- Histats.com  (div with counter) --><div id="histats_counter"></div>
<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,3613766,4,131,112,33,00011111']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?3613766&101" alt="" border="0"></a></noscript>
<!-- Histats.com  END  -->
</div>
		</div></div>
<div class="footer-menu">
<div class="side"><h3>Info Site</h3>			<div class="textwidget"><div class="widget-content" style="-moz-column-count: 2; -webkit-column-count: 2; column-count: 2;">
<div style="font-style: normal; font-weight: normal;"><a href="https://Batchanime.id">- Download Batch</a></div>
<div style="font-style: normal; font-weight: normal;"><a href="https://Batchanime.id">-  Anime Musim ini</a></div>
<div style="font-style: normal; font-weight: normal;"><a href="https://www.paypal.me/Handrian">- Donate</a></div>
<div style="font-style: normal; font-weight: normal;"><a href="https://Batchanime.id">- DMCA</a></div>
<div style="font-style: normal; font-weight: normal;"><a href="https://Batchanime.id">- Privacy Policy</a></div>
<div style="font-style: normal; font-weight: normal;"><a href="https://www.facebook.com/Anime-Search-1256869277667733/">- Facebook Fanpage</a></div></div></div>
		</div></div>

<div class="footer-menu" id="subscribe-footer">
<div class="side"><h3>Partner</h3>			<div class="textwidget"><a height="auto" href="https://animesearch.net"><img width="140" src="http://animesearch.net/wp-content/uploads/2017/03/logofot3.png"/></a>
<a height="auto" href="https://animesearch.net/"><img width="140" src="http://animesearch.net/wp-content/uploads/2017/03/logofot1.png"/></a>
<a height="auto" href="https://animesearch.net"><img width="140" src="http://animesearch.net/wp-content/uploads/2017/03/logofot2.png"/></a>
<a height="auto" href="https://animesearch.net"><img width="140" src="http://animesearch.net/wp-content/uploads/2017/03/logofot4.png"/></a></div>
		</div></div>
</div>
<div id="footme">
<div class="footmekiri col-sm-full">
Copyright © <span id="current-year">2015-2016</span>
<a href="https://www.facebook.com/Animesearch0048" itemprop="creator" itemscope="itemscope" itemtype="http://schema.org/Person"><span itemprop="name">Anime Search</span></a> All Right Reserved.
</div>
<div class="footmekanan col-sm-full">Powered By <a href="http://wordpress.org">Wordpress</a> & <a href="https://www.facebook.com/hiGamerSE/?fref=ts">GamerSE</a></div>
</div>
<div class="clear"></div>
</div>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/uploads/2017/05/safelink-1.js'></script>
<script type='text/javascript'>
protected_links = 'https://batchanime.id,https://www.facebook.com/Animesearch0048'; 
auto_safelink();
</script>
</body>
</html>
<?php ob_flush(); ?>