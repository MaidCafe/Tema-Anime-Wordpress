<?php
/*
Template Name: Ost Anime
*/
?>
<?php get_header(); ?>

<div id="kasumigaoka">
<div id="antblock">
<div class="left">

<div class="right">
</div></div></div>
<div class="clear"></div>
<div class="katobody col-md-8 col-sm-8 col-xs-12" id="main-wrap">
<div class="bodo">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class='titler'>
<h1 class="ttl"><?php the_title(); ?></h1>
<div class='kategori'>
<?php
          setCrunchifyPostViews(get_the_ID());
?>
Released on <?php the_time('jS F, Y'); ?> , <i class='fa fa-eye'></i></b> <?php
          echo getCrunchifyPostViews(get_the_ID());
?> 
</div>
</div>
<div class="text">
<?php the_content(); ?>
</div>
<hr />
<div class='titler'>
<center>
<h1 class="ttl">Link Download</h1>
<i class='fa fa-download'></i>
</center>
<div class='kategori'>
</div>
</div>
<div class="katodl">
<div class="katotl"><h5><?php the_title(); ?>  MP3 </h5></div>
<div class="katourl">
<h6>
<a href="<?php echo get_post_meta($post->ID, 'ost_url1', true);?>"><?php echo get_post_meta($post->ID, 'ost_tittle1', true);?></a>
     |    
<a href="<?php echo get_post_meta($post->ID, 'ost_url2', true);?>"><?php echo get_post_meta($post->ID, 'ost_tittle2', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'ost_url3', true);?>"><?php echo get_post_meta($post->ID, 'ost_tittle3', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'ost_url4', true);?>"><?php echo get_post_meta($post->ID, 'ost_tittle4', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'ost_url5', true);?>"><?php echo get_post_meta($post->ID, 'ost_tittle5', true);?></a>
  |  
</h6>
</div>
</div></div>
<div class="clear"></div>

<div class='socialshare'>
<a href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank" class="sfb"><span class="dashicons dashicons-facebook-alt"></span> Facebook</a>
<a href="http://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank" class="stw"> <span class="dashicons dashicons-twitter"></span> Twitter</a>
<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" class="sgp"><span class="dashicons dashicons-googleplus"></span> Google+</a>
</div>


<div class="clear"></div>
<div class="klands"><img src="http://animesearch.net/wp-content/uploads/2017/01/post-iklan.png"/></div>

<?php get_template_part('relatedpost'); ?>
<?php endwhile; endif; ?>

<div class="clear"></div>

<div class="commentarea">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php echo get_post_meta($post->ID, "embed", true); ?>
<?php comments_template(); ?>
<?php endwhile; endif; ?>
</div></div>



<?php get_template_part('sidebar'); ?>
</div></div>
<?php get_footer(); ?>