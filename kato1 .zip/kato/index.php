<?php get_header(); ?>

<div id="kasumigaoka">
<div id="antblock" class="row-flex cl">
<div class="left">

<div class="right">
</div></div></div>
<div class="clear"></div>
<div class="allinfo">
<?php
//list terms in a given taxonomy
$taxonomy = 'genre';
$tax_terms = get_terms($taxonomy,'number=17');
?>
<ul>
<h2>Genre: </h2>
<?php
foreach ($tax_terms as $tax_term) {
echo '<li>' . '<a href="' . esc_attr(get_term_link($tax_term, $taxonomy)) . '" title="' . sprintf( __( "View all posts in %s" ), $tax_term->name ) . '" ' . '>' . $tax_term->name.'</a></li>';
}
?>
<div class="clear"></div>
</ul>
</div>

<! -- ATASAN -- >

<div class="katobody col-md-8 col-sm-8 col-xs-12" id="main-wrap">
<! -- PUSAT POSTINGAN -- >
<div class="megumi">
<h1 class='arc'>Recent Update</h1>
<div class="megumi-waifuku row-flex">
<?php if ( have_posts() ) : ?>
<?php
if( is_home() ){
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
query_posts( array('post_type'=>array(
'post','batch', 'ost' ),'paged'=>$paged ) );
}
?>
<?php while ( have_posts() ) : the_post(); ?>
<?php get_template_part('articles'); ?>
<?php endwhile; ?>
<div class="clear"></div>
</div>
<div class="clear"></div>
<!-- pagination -->
<div class="pagination"><?php pagenavi(); ?></div>
<div class='clear'></div>
</div>
<!--
<div id="animrel-wrapper" class="animrel-movie">
	<h1 class='animrel-arc'>Featured Series</h1>
	<div class="animrel-row row row-flex">
		<?php
$myposts = array(
    'showposts' => 4,
    'post_type' => 'anime',
    'orderby' => 'rand',
    'tax_query' => array(
        array(
        'taxonomy' => 'status',
        'field' => 'slug',
        'terms' => 'finished')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
		<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
			<div class="animrel-item col-md-3 col-sm-3 col-xs-4">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
					<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?>
					<h2><?php the_title(); ?></h2>
				</a>
			</div>
		<?php endwhile; ?>
	</div>
<div class="clear"></div>
</div>
-->

<div id="animrel-movie" class="animrel-wrapper">
	<h1 class='animrel-arc'>Movie <span><a href='#'>Movie List</a></span></h1>
	<div class="animrel-row row row-flex">
		<?php
$myposts = array(
    'showposts' => 4,
    'post_type' => 'anime',
    'orderby' => 'rand',
    'tax_query' => array(
        array(
        'taxonomy' => 'type',
        'field' => 'slug',
        'terms' => 'movie')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
		<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
			<div class="animrel-item col-md-3 col-sm-3 col-xs-4">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
					<div class="animrel-view"><i class="fa fa-eye"></i><?php echo getCrunchifyPostViews(get_the_ID());?></div>
					<?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(160, 230, true)); }?>
					<h2><?php the_title(); ?></h2>
				</a>

<div class="b">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<p>
<?php echo get_the_term_list( $post->ID, 'rating', '<p><b>Rating </b>: ', ', ', '</p>' ); ?>
</p>
</div>
			</div>
		<?php endwhile; ?>
	</div>
<div class="clear"></div>
</div>

<div id="animrel-special" class="animrel-wrapper">
	<h1 class='animrel-arc'>Special <span><a href='#'>Special List</a></span></h1>
	<div class="animrel-row row row-flex">
	<?php
$myposts = array(
    'showposts' => 4,
    'post_type' => 'anime',
    'orderby' => 'rand',
    'tax_query' => array(
        array(
        'taxonomy' => 'type',
        'field' => 'slug',
        'terms' => 'special')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
		<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
			<div class="animrel-item col-md-3 col-sm-3 col-xs-4">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
					<div class="animrel-view"><i class="fa fa-eye"></i><?php echo getCrunchifyPostViews(get_the_ID());?></div>
					<?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(160, 230, true)); }?>
					<h2><?php the_title(); ?></h2>
				</a>
<div class="b">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<p>
<?php echo get_the_term_list( $post->ID, 'rating', '<p><b>Rating </b>: ', ', ', '</p>' ); ?>
</p>
</div>

			</div>
		<?php endwhile; ?>
	</div>
<div class="clear"></div>
</div>

<div id="animrel-ongoing" class="animrel-wrapper">
	<h1 class='animrel-arc'>Ongoing <span><a href='#'>Ongoing List</a></span></h1>
	<div class="animrel-row row row-flex">
		<?php
$myposts = array(
    'showposts' => 4,
    'post_type' => 'anime',
    'orderby' => 'rand',
    'tax_query' => array(
        array(
        'taxonomy' => 'status',
        'field' => 'slug',
        'terms' => 'ongoing')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
		<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
			<div class="animrel-item col-md-3 col-sm-3 col-xs-4">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
					<div class="animrel-view"><i class="fa fa-eye"></i><?php echo getCrunchifyPostViews(get_the_ID());?></div>
					<?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(160, 230, true)); }?>
					<h2><?php the_title(); ?></h2>
				</a>

<div class="b">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<p>
<?php echo get_the_term_list( $post->ID, 'rating', '<p><b>Rating </b>: ', ', ', '</p>' ); ?>
</p>
</div>
			</div>
		<?php endwhile; ?>
	</div>
<div class="clear"></div>
</div>

<!-- No posts found -->
<?php endif; ?>
</div>

<?php get_template_part('sidebar'); ?>
</div>
<div class="clear"></div>
</div>
</div>

<?php get_footer(); ?>