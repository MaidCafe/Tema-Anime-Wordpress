<?php
/*
Template Name: Genres Anime
*/
?>
<?php get_header(); ?>



<div id="kasumigaoka">
<div id="antblock">
<div class="left">

<div class="right">
</div></div></div>
<div class="clear"></div>
<div class="katobody col-md-8 col-sm-8 col-xs-12">
<h1 class='arc'><b>Genres List</b></h1>
<ul class="genres">
<li>
<?php
//list terms in a given taxonomy
$taxonomy = 'genre';
$tax_terms = get_terms($taxonomy,'number=50');
?>

<?php
foreach ($tax_terms as $tax_term) {
echo '' . '<a href="' . esc_attr(get_term_link($tax_term, $taxonomy)) . '" title="' . sprintf( __( "View all posts in %s" ), $tax_term->name ) . '" ' . '>' . $tax_term->name.'</a>';
}
?></li></ul>
</div>



<?php include (TEMPLATEPATH . '/sidebar.php'); ?>



</div>



<?php get_footer(); ?></div>