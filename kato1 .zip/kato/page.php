<?php get_header(); ?>

<div id="kasumigaoka">
<div id="antblock">
<div class="left">

<div class="right">
</div></div></div>
<div class="clear"></div>
<div class="katobody">
<div class="bodo">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h1 class='arc'><?php the_title(); ?></h1>
<div class="text">
<?php the_content(); ?>
</div>
<div class='clear'></div>
<div class="commentarea">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php echo get_post_meta($post->ID, "embed", true); ?>
<?php comments_template(); ?>
<?php endwhile; endif; ?>
</div></div>
<?php include (TEMPLATEPATH . '/sidebar.php'); ?>
</div>
<?php endwhile; endif; ?>
</div>


<?php get_footer(); ?>