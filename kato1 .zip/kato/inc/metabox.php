<?php
/*
  
@package sunsettheme
  
  ========================
    THEME CUSTOM POST TYPES Batch
  ========================
*/

  $kato = get_option( 'metabox_480p' );
if( @$kato == 1 ){
  add_action( 'add_meta_boxes', 'kato_add_custom_meta_box' );
}

  $megumi = get_option( 'metabox_720p' );
if( @$megumi == 1 ){
  add_action( 'add_meta_boxes', 'megumi_add_custom_meta_box' );
}

  $kasumi = get_option( 'metabox_1080p' );
if( @$kasumi == 1 ){
  add_action( 'add_meta_boxes', 'kasumi_add_custom_meta_box' );
}

  $kato = get_option( 'metabox_mp4' );
if( @$kato == 1 ){

  //quality for animesearch
 
function mp4list_get_sample_options() {
    $options = array (
        '360MKV' => '360MKV',
        '360.MP4' => '360.MP4',
        '480.MP4' => '480.MP4',
        'MP4HD' => 'MP4HD',
        'FullHD' => 'FullHD',
        'MP4' => 'MP4',
    );
    
    return $options;
}
add_action('admin_init', 'mp4list_add_meta_boxes', 1);
function mp4list_add_meta_boxes() {
    add_meta_box( 'mp4listing-fields', 'MP4 Link', 'mp4list_mp4listing_meta_box_display', 'post', 'normal', 'default');
}
function mp4list_mp4listing_meta_box_display() {
    global $post;
    $mp4listing_fields = get_post_meta($post->ID, 'mp4listing_fields', true);
    $options = mp4list_get_sample_options();
    wp_nonce_field( 'mp4list_mp4listing_meta_box_nonce', 'mp4list_mp4listing_meta_box_nonce' );
    ?>
    <script type="text/javascript">
    jQuery(document).ready(function( $ ){
        $( '#add-sfx' ).on('click', function() {
            var sfx = $( '.empty-sfx.screen-reader-text' ).clone(true);
            sfx.removeClass( 'empty-sfx screen-reader-text' );
            sfx.insertBefore( '#mp4listing-fieldset-one tbody>tr:last' );
            return false;
        });
    
        $( '.remove-sfx' ).on('click', function() {
            $(this).parents('tr').remove();
            return false;
        });
    });
    </script>
  
    <table id="mp4listing-fieldset-one" width="100%">
    <thead>
        <tr>
            <th width="12%">Quality</th>
            <th width="40%">URL-1</th>
            <th width="40%">URL-2</th>
            <th width="8%"></th>
        </tr>
    </thead>
    <tbody>
    <?php
    
    if ( $mp4listing_fields ) :
    
    foreach ( $mp4listing_fields as $field ) {
    ?>
    <tr>
    
        <td>
            <select name="select[]">
            <?php foreach ( $options as $label => $value ) : ?>
            <option value="<?php echo $value; ?>"<?php selected( $field['select'], $value ); ?>><?php echo $label; ?></option>
            <?php endforeach; ?>
            </select>
        </td>

    <td><input type="text" class="widefat" name="urls11[]" value="<?php if($field['urls11'] != '') echo esc_attr( $field['urls11'] ); ?>" /></td>

        <td><input type="text" class="widefat" name="urls22[]" value="<?php if ($field['urls22'] != '') echo esc_attr( $field['urls22'] ); else echo 'http://'; ?>" /></td>
    
        <td><a class="button remove-sfx" href="#">Remove</a></td>
    </tr>
    <?php
    }
    else :
    // show a blank one
    ?>
    <tr>
    
        <td>
            <select name="select[]">
            <?php foreach ( $options as $label => $value ) : ?>
            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
            <?php endforeach; ?>
            </select>
        </td>
    
    <td><input type="text" class="widefat" name="urls11[]" /></td>

        <td><input type="text" class="widefat" name="urls22[]" value="http://" /></td>
    
        <td><a class="button remove-sfx" href="#">Remove</a></td>
    </tr>
    <?php endif; ?>
    
    <!-- empty hidden one for jQuery -->
    <tr class="empty-sfx screen-reader-text">
    
        <td>
            <select name="select[]">
            <?php foreach ( $options as $label => $value ) : ?>
            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
            <?php endforeach; ?>
            </select>
        </td>
        
        <td><input type="text" class="widefat" name="urls11[]" /></td>

        <td><input type="text" class="widefat" name="urls22[]" value="http://" /></td>
          
        <td><a class="button remove-sfx" href="#">Remove</a></td>
    </tr>
    </tbody>
    </table>
    
    <p><a id="add-sfx" class="button" href="#">Add another</a></p>
    <?php
}
add_action('save_post', 'mp4list_mp4listing_meta_box_save');
function mp4list_mp4listing_meta_box_save($post_id) {
    if ( ! isset( $_POST['mp4list_mp4listing_meta_box_nonce'] ) ||
    ! wp_verify_nonce( $_POST['mp4list_mp4listing_meta_box_nonce'], 'mp4list_mp4listing_meta_box_nonce' ) )
        return;
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    
    if (!current_user_can('edit_post', $post_id))
        return;
    
    $old = get_post_meta($post_id, 'mp4listing_fields', true);
    $new = array();
    $options = mp4list_get_sample_options();
    
    $names = $_POST['urls11'];
    $selects = $_POST['select'];
    $urls = $_POST['urls22'];
    
    $count = count( $names );
    
    for ( $i = 0; $i < $count; $i++ ) {
        if ( $names[$i] != '' ) :
            $new[$i]['urls11'] = stripslashes( strip_tags( $names[$i] ) );
            
            if ( in_array( $selects[$i], $options ) )
                $new[$i]['select'] = $selects[$i];
            else
                $new[$i]['select'] = '';
        
            if ( $urls[$i] == 'http://' )
                $new[$i]['urls22'] = '';
            else
                $new[$i]['urls22'] = stripslashes( $urls[$i] ); // and however you want to sanitize
        endif;
    }
    if ( !empty( $new ) && $new != $old )
        update_post_meta( $post_id, 'mp4listing_fields', $new );
    elseif ( empty($new) && $old )
        delete_post_meta( $post_id, 'mp4listing_fields', $old );
}

}


  $status = get_option( 'metabox_status' );
if( @$status == 1 ){
  
$prefix = 'dbt_';
$meta_box = array(
    'id' => 'my-meta-box',
    'title' => 'Episode',
    'page' => 'post',
    'context' => 'normal',
    'priority' => 'high',
    'fields' => array(
        array(
            'name' => 'Select Episode',
            'id' => $prefix . 'episodnime',
            'type' => 'select',
            'options' => array(
        'Episode 01',
        'Episode 02',
        'Episode 03',
        'Episode 04',
        'Episode 05',
        'Episode 06',
        'Episode 07',
        'Episode 08',
        'Episode 09',
        'Episode 10',
        'Episode 11',
        'Episode 12',
        'Episode 13',
        'Episode 14',
        'Episode 15',
        'Episode 16',
        'Episode 17',
        'Episode 18',
        'Episode 19',
        'Episode 20',
        'Episode 21',
        'Episode 22',
        'Episode 23',
        'Episode 24',
        'Episode 25',
        'Episode 26',
        'Episode 27',
        'Episode 28',
        'Episode 29',
        'Episode 30',
        'Episode 31',
        'Episode 32',
        'Episode 33',
        'Episode 34',
        'Episode 35',
        'Episode 36',
        'Episode 37',
        'Episode 38',
        'Episode 39',
        'Episode 40',
        'Episode 41',
        'Episode 42',
        'Episode 43',
        'Episode 44',
        'Episode 45',
        'Episode 46',
        'Episode 47',
        'Episode 48',
        'Episode 49',
        'Episode 50',)
        ),
        
    )
);
add_action('admin_menu', 'mytheme_add_box');

// Add meta box
function mytheme_add_box() {
    global $meta_box;

    add_meta_box($meta_box['id'], $meta_box['title'], 'mytheme_show_box', $meta_box['page'], $meta_box['context'], $meta_box['priority']);
}
// Callback function to show fields in meta box
function mytheme_show_box() {
    global $meta_box, $post;

    // Use nonce for verification
    echo '<input type="hidden" name="mytheme_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';

    echo '<table class="form-table">';

    foreach ($meta_box['fields'] as $field) {
        // get current post meta data
        $meta = get_post_meta($post->ID, $field['id'], true);

        echo '<tr>',
                '<th style="width:20%"><label for="', $field['id'], '">', $field['name'], '</label></th>',
                '<td>';
        switch ($field['type']) {
            case 'select':
                echo '<select name="', $field['id'], '" id="', $field['id'], '">';
                foreach ($field['options'] as $option) {
                    echo '<option ', $meta == $option ? ' selected="selected"' : '', '>', $option, '</option>';
                }
                echo '</select>';
                break;
            
        }
        echo     '</td><td>',
            '</td></tr>';
    }

    echo '</table>';
}
add_action('save_post', 'mytheme_save_data');

// Save data from meta box
function mytheme_save_data($post_id) {
    global $meta_box;

    // verify nonce
    if (!wp_verify_nonce($_POST['mytheme_meta_box_nonce'], basename(__FILE__))) {
        return $post_id;
    }

    // check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    // check permissions
    if ('page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } elseif (!current_user_can('edit_post', $post_id)) {
        return $post_id;
    }

    foreach ($meta_box['fields'] as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        $new = $_POST[$field['id']];

        if ($new && $new != $old) {
            update_post_meta($post_id, $field['id'], $new);
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    }
}

}

  $stream = get_option( 'metabox_stream' );
if( @$stream == 1 ){
  add_action( 'add_meta_boxes', 'stream_add_custom_meta_box' );
}


/**
 * Metabox 480p
 */
function kato_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function kato_add_custom_meta_box() {
  add_meta_box( 'kato-meta-box', __( '480p Link', 'kato' ), 'kato_meta_box_output', 'post', 'normal', 'high' );
  add_meta_box( 'kato-meta-box', __( '480p Link', 'kato' ), 'kato_meta_box_output', 'batch', 'normal', 'high' );
  add_meta_box( 'kato-meta-box', __( '480p Link', 'kato' ), 'kato_meta_box_output', 'ost', 'normal', 'high' );
}

/* show on post */
function kato_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_kato_meta_box_nonce', 'kato_meta_box_nonce' ); ?>
  <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kato_url1"><?php _e( 'Link 1', 'kato' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kato_url1" id="kato_url1" value="<?php echo kato_get_custom_field( 'kato_url1' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
  <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kato_url2"><?php _e( 'Link 2', 'kato' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kato_url2" id="kato_url2" value="<?php echo kato_get_custom_field( 'kato_url2' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kato_url3"><?php _e( 'Link 3', 'kato' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kato_url3" id="kato_url3" value="<?php echo kato_get_custom_field( 'kato_url3' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kato_url4"><?php _e( 'Link 4', 'kato' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kato_url4" id="kato_url4" value="<?php echo kato_get_custom_field( 'kato_url4' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kato_url5"><?php _e( 'Link 5', 'kato' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kato_url5" id="kato_url5" value="<?php echo kato_get_custom_field( 'kato_url5' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kato_url6"><?php _e( 'Link 6', 'kato' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kato_url6" id="kato_url6" value="<?php echo kato_get_custom_field( 'kato_url6' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
  <?php
}

/* Save the Meta box values */

function kato_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['kato_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['kato_meta_box_nonce'], 'my_kato_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['kato_url1'] ) )
    update_post_meta( $post_id, 'kato_url1', esc_attr( $_POST['kato_url1'] ) );

    // Save the textarea
  if( isset( $_POST['kato_url2'] ) )
    update_post_meta( $post_id, 'kato_url2', esc_attr( $_POST['kato_url2'] ) );

    // Save the url
  if( isset( $_POST['kato_url3'] ) )
    update_post_meta( $post_id, 'kato_url3', esc_attr( $_POST['kato_url3'] ) );

      // Save the url
  if( isset( $_POST['kato_url4'] ) )
    update_post_meta( $post_id, 'kato_url4', esc_attr( $_POST['kato_url4'] ) );

      // Save the url
  if( isset( $_POST['kato_url5'] ) )
    update_post_meta( $post_id, 'kato_url5', esc_attr( $_POST['kato_url5'] ) );

  if( isset( $_POST['kato_url6'] ) )
    update_post_meta( $post_id, 'kato_url6', esc_attr( $_POST['kato_url6'] ) );
}
add_action( 'save_post', 'kato_meta_box_save' );

/**
 * Metabox 720p
 */
function megumi_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function megumi_add_custom_meta_box() {
  add_meta_box( 'megumi-meta-box', __( '720p Link', 'megumi' ), 'megumi_meta_box_output', 'post', 'normal', 'high' );
  add_meta_box( 'megumi-meta-box', __( '720p Link', 'megumi' ), 'megumi_meta_box_output', 'batch', 'normal', 'high' );
  add_meta_box( 'megumi-meta-box', __( '720p Link', 'megumi' ), 'megumi_meta_box_output', 'ost', 'normal', 'high' );
}

/* show on post */
function megumi_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_megumi_meta_box_nonce', 'megumi_meta_box_nonce' ); ?>
  <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="megumi_url1"><?php _e( 'Link 1', 'megumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="megumi_url1" id="megumi_url1" value="<?php echo megumi_get_custom_field( 'megumi_url1' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
  <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="megumi_url2"><?php _e( 'Link 2', 'megumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="megumi_url2" id="megumi_url2" value="<?php echo megumi_get_custom_field( 'megumi_url2' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="megumi_url3"><?php _e( 'Link 3', 'megumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="megumi_url3" id="megumi_url3" value="<?php echo megumi_get_custom_field( 'megumi_url3' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="megumi_url4"><?php _e( 'Link 4', 'megumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="megumi_url4" id="megumi_url4" value="<?php echo megumi_get_custom_field( 'megumi_url4' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="megumi_url5"><?php _e( 'Link 5', 'megumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="megumi_url5" id="megumi_url5" value="<?php echo megumi_get_custom_field( 'megumi_url5' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="megumi_url6"><?php _e( 'Link 6', 'megumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="megumi_url6" id="megumi_url6" value="<?php echo megumi_get_custom_field( 'megumi_url6' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
  <?php
}

/* Save the Meta box values */

function megumi_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['megumi_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['megumi_meta_box_nonce'], 'my_megumi_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['megumi_url1'] ) )
    update_post_meta( $post_id, 'megumi_url1', esc_attr( $_POST['megumi_url1'] ) );

    // Save the textarea
  if( isset( $_POST['megumi_url2'] ) )
    update_post_meta( $post_id, 'megumi_url2', esc_attr( $_POST['megumi_url2'] ) );

    // Save the url
  if( isset( $_POST['megumi_url3'] ) )
    update_post_meta( $post_id, 'megumi_url3', esc_attr( $_POST['megumi_url3'] ) );

      // Save the url
  if( isset( $_POST['megumi_url4'] ) )
    update_post_meta( $post_id, 'megumi_url4', esc_attr( $_POST['megumi_url4'] ) );

      // Save the url
  if( isset( $_POST['megumi_url5'] ) )
    update_post_meta( $post_id, 'megumi_url5', esc_attr( $_POST['megumi_url5'] ) );

  if( isset( $_POST['megumi_url6'] ) )
    update_post_meta( $post_id, 'megumi_url6', esc_attr( $_POST['megumi_url6'] ) );
}
add_action( 'save_post', 'megumi_meta_box_save' );

 
/**
 * Metabox 1080p
 */
function kasumi_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function kasumi_add_custom_meta_box() {
  add_meta_box( 'kasumi-meta-box', __( '1080p Link', 'kasumi' ), 'kasumi_meta_box_output', 'post', 'normal', 'high' );
  add_meta_box( 'kasumi-meta-box', __( '1080p Link', 'kasumi' ), 'kasumi_meta_box_output', 'batch', 'normal', 'high' );
  add_meta_box( 'kasumi-meta-box', __( '1080p Link', 'kasumi' ), 'kasumi_meta_box_output', 'ost', 'normal', 'high' );
}

/* show on post */
function kasumi_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_kasumi_meta_box_nonce', 'kasumi_meta_box_nonce' ); ?>
  <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kasumi_url1"><?php _e( 'Link 1', 'kasumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kasumi_url1" id="kasumi_url1" value="<?php echo kasumi_get_custom_field( 'kasumi_url1' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
  <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kasumi_url2"><?php _e( 'Link 2', 'kasumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kasumi_url2" id="kasumi_url2" value="<?php echo kasumi_get_custom_field( 'kasumi_url2' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kasumi_url3"><?php _e( 'Link 3', 'kasumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kasumi_url3" id="kasumi_url3" value="<?php echo kasumi_get_custom_field( 'kasumi_url3' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kasumi_url4"><?php _e( 'Link 4', 'kasumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kasumi_url4" id="kasumi_url4" value="<?php echo kasumi_get_custom_field( 'kasumi_url4' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kasumi_url5"><?php _e( 'Link 5', 'kasumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kasumi_url5" id="kasumi_url5" value="<?php echo kasumi_get_custom_field( 'kasumi_url5' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
    <table class="form-table">
  <tr>
  <tr>
    <td width="20%" style="padding:4px 0px!important;"><label for="kasumi_url6"><?php _e( 'Link 6', 'kasumi' ); ?>:</label></td>
    <td style="padding:4px 0px!important;">
    <input class="widefat" type="text" name="kasumi_url6" id="kasumi_url6" value="<?php echo kasumi_get_custom_field( 'kasumi_url6' ); ?>" placeholder="Link Download" size="30" style="width:100%" />
  </td></tr>
  </table>
  <?php
}

/* Save the Meta box values */

function kasumi_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['kasumi_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['kasumi_meta_box_nonce'], 'my_kasumi_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['kasumi_url1'] ) )
    update_post_meta( $post_id, 'kasumi_url1', esc_attr( $_POST['kasumi_url1'] ) );

    // Save the textarea
  if( isset( $_POST['kasumi_url2'] ) )
    update_post_meta( $post_id, 'kasumi_url2', esc_attr( $_POST['kasumi_url2'] ) );

    // Save the url
  if( isset( $_POST['kasumi_url3'] ) )
    update_post_meta( $post_id, 'kasumi_url3', esc_attr( $_POST['kasumi_url3'] ) );

      // Save the url
  if( isset( $_POST['kasumi_url4'] ) )
    update_post_meta( $post_id, 'kasumi_url4', esc_attr( $_POST['kasumi_url4'] ) );

      // Save the url
  if( isset( $_POST['kasumi_url5'] ) )
    update_post_meta( $post_id, 'kasumi_url5', esc_attr( $_POST['kasumi_url5'] ) );

  if( isset( $_POST['kasumi_url6'] ) )
    update_post_meta( $post_id, 'kasumi_url6', esc_attr( $_POST['kasumi_url6'] ) );
}
add_action( 'save_post', 'kasumi_meta_box_save' );


/**
 * Metabox Status Streaming
 */
function stream_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function stream_add_custom_meta_box() {
  add_meta_box( 'stream-meta-box', __( 'Streaming Link', 'stream' ), 'stream_meta_box_output', 'post', 'normal', 'high' );

}

/* show on post */
function stream_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_stream_meta_box_nonce', 'stream_meta_box_nonce' ); ?>
  
  <p>
    <label for="stream_url1"><?php _e( 'Google', 'stream' ); ?>:</label>
    <input class="widefat" type="text" name="stream_url1" id="stream_url1" value="<?php echo stream_get_custom_field( 'stream_url1' ); ?>" size="50" placeholder="Google Drive Video link" />
    </p>

  <p>
    <label for="stream_url2"><?php _e( 'Openload', 'stream' ); ?>:</label>
    <input class="widefat" type="text" name="stream_url2" id="stream_url2" value="<?php echo stream_get_custom_field( 'stream_url2' ); ?>" size="50" placeholder="Openload Video link" />
    </p>
  
  <p>
    <label for="stream_url3"><?php _e( 'MP4upload', 'stream' ); ?>:</label>
    <input class="widefat" type="text" name="stream_url3" id="stream_url3" value="<?php echo stream_get_custom_field( 'stream_url3' ); ?>" size="50" placeholder="MP4upload Video link" />
    </p>

  <?php
}

/* Save the Meta box values */

function stream_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['stream_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['stream_meta_box_nonce'], 'my_stream_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

    // Save the textfield
  if( isset( $_POST['stream_url1'] ) )
    update_post_meta( $post_id, 'stream_url1', esc_attr( $_POST['stream_url1'] ) );

      // Save the textfield
  if( isset( $_POST['stream_url2'] ) )
    update_post_meta( $post_id, 'stream_url2', esc_attr( $_POST['stream_url2'] ) );

    // Save the textarea
  if( isset( $_POST['stream_url3'] ) )
    update_post_meta( $post_id, 'stream_url3', esc_attr( $_POST['stream_url3'] ) );
}
add_action( 'save_post', 'stream_meta_box_save' );
