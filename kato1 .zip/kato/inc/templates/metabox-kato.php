<?php settings_errors(); ?>
</form>
<div class="wrap">
<form method="post" action="options.php">
<div class='wrap-swap'><h2><img src="<?php echo get_template_directory_uri(); ?>/img/kato-icon.png">Kato Metabox Configuration</h2><?php submit_button(); ?><div class="clear"></div></div>
    
    <div class="main-config">
    <h3>Metabox Setting</h3>
    <?php settings_fields( 'kato-metabox-act' ); ?>
    <?php do_settings_sections( 'megumi_katobox' ); ?>
    </div>
    <?php submit_button(); ?>
</form>
<style type='text/css'>.main-config{background:#FFF;padding:0 25px 5px;margin-bottom:30px;border:1px solid #ddd}.main-config>h3{background:#7DC168;padding:15px;margin:-10px -25px 0;color:#FFF;text-transform:uppercase}.wrap-swap{margin:20px auto 30px}.wrap-swap>h2{float:left;margin:0;text-transform:uppercase;font-size:20px;padding-top:5px}.wrap-swap p.submit{margin:0;display:inline-block;margin-left:15px;padding:0}._multi>input{margin-right:15px}.wrap-swap>h2 img{max-width:22px;float:left;margin-right:10px}</style>
</div>
