<div class="ongoingrekommm">
<div class="kano">
<div class="ongogambarrr">
<div class="episo"><?php
          echo getCrunchifyPostViews(get_the_ID());?>
</div>
<div class="episode"><?php echo get_post_meta($post->ID, 'eps_url1', true);?>
</div>
<?php
$valky = get_the_term_list( $post->ID , 'idnum' );
    $args = array(
        'post_type' => 'anime',
        'post__not_in' => array( get_the_ID() ),
        'posts_per_page' => 1,
        'idnam'     => $valky,
        'meta_query' => array(
                    array(
                    
                        )
                    )
    );
    $query = new WP_Query( $args );

?>  

<?php if( $query->have_posts() ) : while( $query->have_posts() ) : $query->the_post(); ?>

<div class="status"><?php echo get_the_term_list( $post->ID, 'status', '', ', ', '' ); ?>
</div>
<?php endwhile; endif; wp_reset_postdata(); ?>
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }
else {
 echo '<img src="https://animesearch.net/wp-content/uploads/2017/03/bg-player.jpg"></img>';
}
?>
<h2 class='epis'><?php the_title(); ?></h2>
</div></a>
</div>
</div>