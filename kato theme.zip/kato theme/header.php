<?php ob_start(); ?>
﻿﻿﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<html prefix="og: http://ogp.me/ns#">
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title( '–', true, 'right' ); ?></title>

<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />

<link rel="icon" href="https://animesearch.net/wp-content/uploads/2017/03/fav-60x60.jpg" sizes="32x32" />
<link rel="icon" href="https://animesearch.net/wp-content/uploads/2017/03/fav.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://animesearch.net/wp-content/uploads/2017/03/fav.jpg" />
<meta name="msapplication-TileImage" content="https://animesearch.net/wp-content/uploads/2017/03/fav.jpg" />
<meta charset="<?php bloginfo('charset'); ?>">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content='Index, Follow' name='robots'/>
<meta content='Admin' name='author'/>
<meta content='Download Streaming Anime Subtitle Indonesia' name='keywords'/>
<meta content='Download Streaming Anime Subtitle Indonesia Anime Search Database' name='description'/>
<meta content='© <?php echo date("Y") ?> <?php bloginfo('name'); ?>' name='copyright'/>
<meta content='Indonesia' name='geo.placename'/>
<meta content='ID' name='language'/>
<meta content='ID' name='geo.country'/>
<meta content='All-Language' http-equiv='Content-Language'/>
<meta content='global' name='distribution'/>
<meta content='blogger' name='generator'/>
<meta content='general' name='rating'/>
<meta content='global' name='target'/>
<meta content='true' name='MSSmartTagsPreventParsing'/>
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
<meta content='index, follow' name='googlebot'/>
<meta content='follow, all' name='Googlebot-Image'/>
<meta content='follow, all' name='msnbot'/>
<meta content='follow, all' name='Slurp'/>
<meta content='follow, all' name='ZyBorg'/>
<meta content='follow, all' name='Scooter'/>
<meta content='all' name='spiders'/>
<meta content='all' name='WEBCRAWLERS'/>
<meta content='noodp' name='robots'/>
<meta content='noydir' name='robots'/>
<meta content='Download Anime Subtitle Indonesia, Download Anime Batch Subtitle Indonesia , Download Anime sub indo , Download anime batch , download anime batch sub indo , download anime sub , download anime indo , animeindo , donlod anime subtitle indonesia , donlod anime sub indo , download anime batch subtitle indonesia terlengkap , streaming anime sub indo , stream anime sub indonesia' name='search engines'/>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<meta property="og:image" content="https://animesearch.net/wp-content/uploads/2017/03/logofot2.png" />

<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css' rel='stylesheet'/>
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link type="text/css" rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700|Roboto:400,500,700"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<meta name="msvalidate.01" content="E8F5977B60320B346B828579A09479C2" />

<script src='//cdnjs.cloudflare.com/ajax/libs/angular.js/1.3.14/angular.min.js'></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-92274544-2', 'auto');
  ga('send', 'pageview');

</script>

<?php wp_head(); ?>
</head>

<body>

<script>
var myApp=angular.module('tabs',[]);
myApp.controller('shift_tabs',function(){
  this.activeTab;
  this.makeShift=function(e){
    this.activeTab=e;
  }
  this.isActive=function(f){
    if(f==this.activeTab){
      return true
    }
  }
});
</script>
  
<div id="headerwrap" class="container">
<header id="header">
<div class="site-logo"><a href="http://animesearch.net/"><img src='https://animesearch.net/wp-content/uploads/2017/03/head-logo.gif'/></a></div>
<div id="header-name"></div>

</header>

<nav id="menu-kato">
<div class='penengah' style='margin:auto;max-width:995px;'>
<?php 
ob_start();
$nav_menu = wp_nav_menu(array('theme_location'=>'main', 'container'=>'', 'fallback_cb' => '', 'echo' => 0)); 
if(empty($nav_menu))
$nav_menu = '<ul>'.wp_list_categories(array('show_option_all'=>__('Home', 'dp'), 'title_li'=>'', 'echo'=>0)).'</ul>';
echo $nav_menu;
?>
<form role="search" method="get" id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input type="text" value="" name="s" id="s" placeholder="Cari Anime...">
<input type="hidden" name="post_type" value="anime" />
</div>
</form>

<div class="clear"></div>
</nav>

<div id="wiburekomended">
<h2>Recomended Anime</h2>
<?php
$myposts = array(
'showposts' => 6,
'post_type' => 'anime',
'orderby' => 'rand',
'tax_query' => array(
)
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
<div class="tip"><?php the_title(); ?></div>
<?php endwhile; ?>
<?php wp_reset_query(); ?>
</div>

</div>
<div id="kasumiwrap" class="container">