<?php
/*
Template Name: Anime Upcoming
*/

get_header(); ?>

<div id="kasumigaoka">
<div id="antblock">
<div class="left">

<div class="right">
</div></div></div>
<div class="clear"></div>
<div class="katobody">
<h1 class='arc'>Anime Upcoming</h1>

<div class="ongoingrekom">
<div class="listongo">
<?php
$myposts = array(
    'showposts' => 16,
    'post_type' => 'anime',
    'orderby' => '',
    'tax_query' => array(
        array(
        'taxonomy' => 'status',
        'field' => 'slug',
        'terms' => 'Upcoming')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
<div class="boxreko">
<div class="ongogambar"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?><h2><?php the_title(); ?></h2></a></div>
</div>
<?php endwhile; ?></div></div></div>
<?php get_template_part('sidebar'); ?>
</div>
</div>
<?php get_footer(); ?>