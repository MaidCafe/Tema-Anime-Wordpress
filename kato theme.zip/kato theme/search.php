<?php get_header(); ?>



<div id="kasumigaoka">

<div id="antblock">
<div class="left">

<div class="right">
</div></div></div>
<div class="clear"></div>

<div class="katobody">



<div class="postz">

        <?php if (have_posts()) : ?>



         <h1 class='arc'><b>Search Results</b></h1>

      

<div style="padding:1px 0;">
<?php while (have_posts()) : the_post(); ?>


<div class="airi">
<div class="airiecchi"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?></div>
<div class="airizone">
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<div class="genreecchi"><?php echo get_the_term_list( $post->ID, 'status', '<p><b>Status </b>: ', '</p>' ); ?></div>
<div class="genreecchi"><?php echo get_the_term_list( $post->ID, 'genre', '<p><b>Genre </b>: ', ', ', '</p>' ); ?></div>

<div class="genreecchi"><?php echo get_the_term_list( $post->ID, 'episodes', '<p><b>Total Episode </b>: ', '</p>' ); ?></div>

<div class="genreecchi"><?php echo get_the_term_list( $post->ID, 'rating', '<p><b>Rating </b>: ', ', ', '</p>' ); ?></div>
</div>
</div>
<?php endwhile; ?>

<div class="navigation">

<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>  

</div>

    <?php else : ?>



        <h2 class="center">No posts found. Try a different search?</h2>



    <?php endif; ?>

</div>
</div>
</div>

<?php get_template_part('sidebar'); ?>
</div>

<?php get_footer(); ?>