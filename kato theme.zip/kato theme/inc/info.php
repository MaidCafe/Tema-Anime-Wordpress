<?php function sagirih_info(){ ?>
		<div class="animeinfo">
      <div class="left">
			<?php // METHOD 1
			foreach((get_the_category()) as $anim_slug){
			$animu = new WP_Query(array('post_type' => 'anime','s' => $anim_slug->cat_name,'showposts' => '1'));
			while($animu->have_posts()) : $animu->the_post(); ?>
			<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?>
<b>Judul</b> : <a href='<?php the_permalink(); ?>'><?php the_title(); ?></a>
<?php echo get_the_term_list( $post->ID, 'type', '<p><b>Type </b>: ', '</p>' ); ?>
<?php echo get_the_term_list( $post->ID, 'status', '<p><b>Status </b>: ', ', ', '</p>' ); ?>
<?php echo get_the_term_list( $post->ID, 'episodes', '<p><b>Total Episode </b>: ', '</p>' ); ?>
<?php echo get_the_term_list( $post->ID, 'rating', '<p><b>Rating </b>: ', ', ', '</p>' ); ?>
<?php echo get_the_term_list( $post->ID, 'duration', '<p><b>Durasi </b>: ', '</p>' ); ?>
<?php echo get_the_term_list( $post->ID, 'seasons', '<p><b>Seasons </b>: ', ', ', '</p>' ); ?>
<?php echo get_the_term_list( $post->ID, 'genre', '<p><b>Genre </b>: ', ', ', '</p>' ); ?>
            </div>
        <?php endwhile; wp_reset_postdata(); }?>
			<div class="right">
<?php  // METHOD 2
			$anim =  get_the_category(); $anim_slug = $anim[0]->slug;
			$animu = new WP_Query(array('post_type' => 'anime','post__not_in' => array($anim_slug),'showposts' => '4','orderby' => 'rand'));
			while($animu->have_posts()) : $animu->the_post(); ?>
			<ul class="related">
				<li>
					<div class="gambarg">
					
						<div class="limiter">
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php 
			if(has_post_thumbnail()){
				the_post_thumbnail();
			} else {
				echo '<img height="130" width="180" src="',get_template_directory_uri(),'/img/megumi.png" class="thumbnail no-img" alt="Thumbnail no image">';
			}
			?></a>
						</div>
					</div>
					<div class="rights">
						<span class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
						<span class="cat"><?php echo get_the_term_list( $post->ID, 'genre', '', ', ', '</p>' ); ?></span>
					</div>
				</li>
			</ul>
			<?php endwhile; wp_reset_postdata();?>	
			
</div>

          <div class="clear"></div>
                        <div class="sinop">
<?php // METHOD 1
			foreach((get_the_category()) as $anim_slug){
			$animu = new WP_Query(array('post_type' => 'anime','s' => $anim_slug->cat_name,'showposts' => '1'));
			while($animu->have_posts()) : $animu->the_post(); ?>
<p><?php echo wp_trim_words( get_the_content(), 50, '...' ); ?></p>
</div>
<?php endwhile; wp_reset_postdata(); }?>
</div>
		
<?php } ?>
<?php

function sagirih_seeall(){
	$category = get_the_category()[0];
	echo '<a href="'. esc_url(home_url( '/anime/' ) . esc_attr( $category->slug )) .'" title="see all episode '.esc_attr( $category->name ).'">',get_option('config_seeall')?:'See All Episode','</a>';	
}

/* == PAGINASI == */
function sagirih_pagination(){
	echo '<span class="anipager-prev">', previous_post_link('%link', get_option('config_prev')?:'<i class="fa fa-angle-left"></i> Previous', true) ,'</span>';
	echo '<span class="anipager-seeall">', sagirih_seeall() ,'</span>';
	echo '<span class="anipager-next">', next_post_link('%link', get_option('config_next')?:'Next <i class="fa fa-angle-right"></i>', true) ,'</span>';
}