<?php
/*
  
@package sunsettheme
  
  ========================
    THEME CUSTOM POST TYPES Batch
  ========================
*/

  $kato = get_option( 'metabox_480p' );
if( @$kato == 1 ){
  add_action( 'add_meta_boxes', 'kato_add_custom_meta_box' );
}

  $megumi = get_option( 'metabox_720p' );
if( @$megumi == 1 ){
  add_action( 'add_meta_boxes', 'megumi_add_custom_meta_box' );
}

  $kasumi = get_option( 'metabox_1080p' );
if( @$kasumi == 1 ){
  add_action( 'add_meta_boxes', 'kasumi_add_custom_meta_box' );
}

  $status = get_option( 'metabox_status' );
if( @$status == 1 ){
  add_action( 'add_meta_boxes', 'eps_add_custom_meta_box' );
}

  $stream = get_option( 'metabox_stream' );
if( @$stream == 1 ){
  add_action( 'add_meta_boxes', 'stream_add_custom_meta_box' );
}

/**
 * Metabox 480p
 */
function kato_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function kato_add_custom_meta_box() {
  add_meta_box( 'kato-meta-box', __( '480p Link', 'kato' ), 'kato_meta_box_output', 'post', 'normal', 'high' );

}

/* show on post */
function kato_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_kato_meta_box_nonce', 'kato_meta_box_nonce' ); ?>
  
  <p>
    <label for="kato_url1"><?php _e( 'Link 1', 'kato' ); ?>:</label>
    <input type="text" name="kato_tittle1" id="kato_tittle1" value="<?php echo kato_get_custom_field( 'kato_tittle1' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kato_url1" id="kato_url1" value="<?php echo kato_get_custom_field( 'kato_url1' ); ?>" size="50" placeholder="Link Download" />
    </p>
  
  <p>
    <label for="kato_url2"><?php _e( 'Link 2', 'kato' ); ?>:</label>
    <input type="text" name="kato_tittle2" id="kato_tittle2" value="<?php echo kato_get_custom_field( 'kato_tittle2' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kato_url2" id="kato_url2" value="<?php echo kato_get_custom_field( 'kato_url2' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="kato_url3"><?php _e( 'Link 3', 'kato' ); ?>:</label>
    <input type="text" name="kato_tittle3" id="kato_tittle3" value="<?php echo kato_get_custom_field( 'kato_tittle3' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kato_url3" id="kato_url3" value="<?php echo kato_get_custom_field( 'kato_url3' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="kato_url4"><?php _e( 'Link 4', 'kato' ); ?>:</label>
    <input type="text" name="kato_tittle4" id="kato_tittle4" value="<?php echo kato_get_custom_field( 'kato_tittle4' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kato_url4" id="kato_url4" value="<?php echo kato_get_custom_field( 'kato_url4' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="kato_url5"><?php _e( 'Link 5', 'kato' ); ?>:</label>
    <input type="text" name="kato_tittle5" id="kato_tittle5" value="<?php echo kato_get_custom_field( 'kato_tittle5' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kato_url5" id="kato_url5" value="<?php echo kato_get_custom_field( 'kato_url5' ); ?>" size="50" placeholder="Link Download" />
    </p>
  <?php
}

/* Save the Meta box values */

function kato_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['kato_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['kato_meta_box_nonce'], 'my_kato_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['kato_url1'] ) )
    update_post_meta( $post_id, 'kato_url1', esc_attr( $_POST['kato_url1'] ) );

    // Save the textarea
  if( isset( $_POST['kato_url2'] ) )
    update_post_meta( $post_id, 'kato_url2', esc_attr( $_POST['kato_url2'] ) );

    // Save the url
  if( isset( $_POST['kato_url3'] ) )
    update_post_meta( $post_id, 'kato_url3', esc_attr( $_POST['kato_url3'] ) );

      // Save the url
  if( isset( $_POST['kato_url4'] ) )
    update_post_meta( $post_id, 'kato_url4', esc_attr( $_POST['kato_url4'] ) );

      // Save the url
  if( isset( $_POST['kato_url5'] ) )
    update_post_meta( $post_id, 'kato_url5', esc_attr( $_POST['kato_url5'] ) );
        // Save the url
  if( isset( $_POST['kato_tittle1'] ) )
    update_post_meta( $post_id, 'kato_tittle1', esc_attr( $_POST['kato_tittle1'] ) );

  if( isset( $_POST['kato_tittle2'] ) )
    update_post_meta( $post_id, 'kato_tittle2', esc_attr( $_POST['kato_tittle2'] ) );

  if( isset( $_POST['kato_tittle3'] ) )
    update_post_meta( $post_id, 'kato_tittle3', esc_attr( $_POST['kato_tittle3'] ) );

 if( isset( $_POST['kato_tittle4'] ) )
    update_post_meta( $post_id, 'kato_tittle4', esc_attr( $_POST['kato_tittle4'] ) );

  if( isset( $_POST['kato_tittle5'] ) )
    update_post_meta( $post_id, 'kato_tittle5', esc_attr( $_POST['kato_tittle5'] ) );
}
add_action( 'save_post', 'kato_meta_box_save' );

/**
 * Metabox 720p
 */
function megumi_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function megumi_add_custom_meta_box() {
  add_meta_box( 'megumi-meta-box', __( '720p Link', 'megumi' ), 'megumi_meta_box_output', 'post', 'normal', 'high' );

}

/* show on post */
function megumi_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_megumi_meta_box_nonce', 'megumi_meta_box_nonce' ); ?>
  
  <p>
    <label for="megumi_url1"><?php _e( 'Link 1', 'megumi' ); ?>:</label>
    <input type="text" name="megumi_tittle1" id="megumi_tittle1" value="<?php echo megumi_get_custom_field( 'megumi_tittle1' ); ?>" size="18" Placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="megumi_url1" id="megumi_url1" value="<?php echo megumi_get_custom_field( 'megumi_url1' ); ?>" size="50" Placeholder="Link Download" />
    </p>
  
  <p>
    <label for="megumi_url2"><?php _e( 'Link 2', 'megumi' ); ?>:</label>
    <input type="text" name="megumi_tittle2" id="megumi_tittle2" value="<?php echo megumi_get_custom_field( 'megumi_tittle2' ); ?>" size="18" Placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="megumi_url2" id="megumi_url2" value="<?php echo megumi_get_custom_field( 'megumi_url2' ); ?>" size="50" Placeholder="Link Download" />
    </p>

   <p>
    <label for="megumi_url3"><?php _e( 'Link 3', 'megumi' ); ?>:</label>
    <input type="text" name="megumi_tittle3" id="megumi_tittle3" value="<?php echo megumi_get_custom_field( 'megumi_tittle3' ); ?>" size="18" Placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="megumi_url3" id="megumi_url3" value="<?php echo megumi_get_custom_field( 'megumi_url3' ); ?>" size="50" Placeholder="Link Download" />
    </p>

   <p>
    <label for="megumi_url4"><?php _e( 'Link 4', 'megumi' ); ?>:</label>
    <input type="text" name="megumi_tittle4" id="megumi_tittle4" value="<?php echo megumi_get_custom_field( 'megumi_tittle4' ); ?>" size="18" Placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="megumi_url4" id="megumi_url4" value="<?php echo megumi_get_custom_field( 'megumi_url4' ); ?>" size="50" Placeholder="Link Download" />
    </p>

   <p>
    <label for="megumi_url5"><?php _e( 'Link 5', 'megumi' ); ?>:</label>
    <input type="text" name="megumi_tittle5" id="megumi_tittle5" value="<?php echo megumi_get_custom_field( 'megumi_tittle5' ); ?>" size="18" Placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="megumi_url5" id="megumi_url5" value="<?php echo megumi_get_custom_field( 'megumi_url5' ); ?>" size="50" Placeholder="Link Download" />
    </p>
  <?php
}

/* Save the Meta box values */

function megumi_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['megumi_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['megumi_meta_box_nonce'], 'my_megumi_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['megumi_url1'] ) )
    update_post_meta( $post_id, 'megumi_url1', esc_attr( $_POST['megumi_url1'] ) );

    // Save the textarea
  if( isset( $_POST['megumi_url2'] ) )
    update_post_meta( $post_id, 'megumi_url2', esc_attr( $_POST['megumi_url2'] ) );

    // Save the url
  if( isset( $_POST['megumi_url3'] ) )
    update_post_meta( $post_id, 'megumi_url3', esc_attr( $_POST['megumi_url3'] ) );

      // Save the url
  if( isset( $_POST['megumi_url4'] ) )
    update_post_meta( $post_id, 'megumi_url4', esc_attr( $_POST['megumi_url4'] ) );

      // Save the url
  if( isset( $_POST['megumi_url5'] ) )
    update_post_meta( $post_id, 'megumi_url5', esc_attr( $_POST['megumi_url5'] ) );
        // Save the url
  if( isset( $_POST['megumi_tittle1'] ) )
    update_post_meta( $post_id, 'megumi_tittle1', esc_attr( $_POST['megumi_tittle1'] ) );

  if( isset( $_POST['megumi_tittle2'] ) )
    update_post_meta( $post_id, 'megumi_tittle2', esc_attr( $_POST['megumi_tittle2'] ) );

  if( isset( $_POST['megumi_tittle3'] ) )
    update_post_meta( $post_id, 'megumi_tittle3', esc_attr( $_POST['megumi_tittle3'] ) );

 if( isset( $_POST['megumi_tittle4'] ) )
    update_post_meta( $post_id, 'megumi_tittle4', esc_attr( $_POST['megumi_tittle4'] ) );

  if( isset( $_POST['megumi_tittle5'] ) )
    update_post_meta( $post_id, 'megumi_tittle5', esc_attr( $_POST['megumi_tittle5'] ) );
}
add_action( 'save_post', 'megumi_meta_box_save' );

 
/**
 * Metabox 1080p
 */
function kasumi_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function kasumi_add_custom_meta_box() {
  add_meta_box( 'kasumi-meta-box', __( '1080p Link', 'kasumi' ), 'kasumi_meta_box_output', 'post', 'normal', 'high' );


}

/* show on post */
function kasumi_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_kasumi_meta_box_nonce', 'kasumi_meta_box_nonce' ); ?>
  
  <p>
    <label for="kasumi_url1"><?php _e( 'Link 1', 'kasumi' ); ?>:</label>
    <input type="text" name="kasumi_tittle1" id="kasumi_tittle1" value="<?php echo kasumi_get_custom_field( 'kasumi_tittle1' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kasumi_url1" id="kasumi_url1" value="<?php echo kasumi_get_custom_field( 'kasumi_url1' ); ?>" size="50" placeholder="Link Download" />
    </p>
  
  <p>
    <label for="kasumi_url2"><?php _e( 'Link 2', 'kasumi' ); ?>:</label>
    <input type="text" name="kasumi_tittle2" id="kasumi_tittle2" value="<?php echo kasumi_get_custom_field( 'kasumi_tittle2' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kasumi_url2" id="kasumi_url2" value="<?php echo kasumi_get_custom_field( 'kasumi_url2' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="kasumi_url3"><?php _e( 'Link 3', 'kasumi' ); ?>:</label>
    <input type="text" name="kasumi_tittle3" id="kasumi_tittle3" value="<?php echo kasumi_get_custom_field( 'kasumi_tittle3' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kasumi_url3" id="kasumi_url3" value="<?php echo kasumi_get_custom_field( 'kasumi_url3' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="kasumi_url4"><?php _e( 'Link 4', 'kasumi' ); ?>:</label>
    <input type="text" name="kasumi_tittle4" id="kasumi_tittle4" value="<?php echo kasumi_get_custom_field( 'kasumi_tittle4' ); ?>" size="18" placeholder="Link Download" />
    <br />
    <input class="widefat" type="text" name="kasumi_url4" id="kasumi_url4" value="<?php echo kasumi_get_custom_field( 'kasumi_url4' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="kasumi_url5"><?php _e( 'Link 5', 'kasumi' ); ?>:</label>
    <input type="text" name="kasumi_tittle5" id="kasumi_tittle5" value="<?php echo kasumi_get_custom_field( 'kasumi_tittle5' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="kasumi_url5" id="kasumi_url5" value="<?php echo kasumi_get_custom_field( 'kasumi_url5' ); ?>" size="50" placeholder="Link Download" />
    </p>
  <?php
}

/* Save the Meta box values */

function kasumi_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['kasumi_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['kasumi_meta_box_nonce'], 'my_kasumi_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['kasumi_url1'] ) )
    update_post_meta( $post_id, 'kasumi_url1', esc_attr( $_POST['kasumi_url1'] ) );

    // Save the textarea
  if( isset( $_POST['kasumi_url2'] ) )
    update_post_meta( $post_id, 'kasumi_url2', esc_attr( $_POST['kasumi_url2'] ) );

    // Save the url
  if( isset( $_POST['kasumi_url3'] ) )
    update_post_meta( $post_id, 'kasumi_url3', esc_attr( $_POST['kasumi_url3'] ) );

      // Save the url
  if( isset( $_POST['kasumi_url4'] ) )
    update_post_meta( $post_id, 'kasumi_url4', esc_attr( $_POST['kasumi_url4'] ) );

      // Save the url
  if( isset( $_POST['kasumi_url5'] ) )
    update_post_meta( $post_id, 'kasumi_url5', esc_attr( $_POST['kasumi_url5'] ) );
        // Save the url
  if( isset( $_POST['kasumi_tittle1'] ) )
    update_post_meta( $post_id, 'kasumi_tittle1', esc_attr( $_POST['kasumi_tittle1'] ) );

  if( isset( $_POST['kasumi_tittle2'] ) )
    update_post_meta( $post_id, 'kasumi_tittle2', esc_attr( $_POST['kasumi_tittle2'] ) );

  if( isset( $_POST['kasumi_tittle3'] ) )
    update_post_meta( $post_id, 'kasumi_tittle3', esc_attr( $_POST['kasumi_tittle3'] ) );

 if( isset( $_POST['kasumi_tittle4'] ) )
    update_post_meta( $post_id, 'kasumi_tittle4', esc_attr( $_POST['kasumi_tittle4'] ) );

  if( isset( $_POST['kasumi_tittle5'] ) )
    update_post_meta( $post_id, 'kasumi_tittle5', esc_attr( $_POST['kasumi_tittle5'] ) );
}
add_action( 'save_post', 'kasumi_meta_box_save' );

 
/**
 * Metabox Status Episode
 */
function eps_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function eps_add_custom_meta_box() {
  add_meta_box( 'eps-meta-box', __( 'Episode Link', 'eps' ), 'eps_meta_box_output', 'post', 'normal', 'high' );
  add_meta_box( 'eps-meta-box', __( 'Episode Link', 'eps' ), 'eps_meta_box_output', 'batch', 'normal', 'high' );
  add_meta_box( 'eps-meta-box', __( 'Episode Link', 'eps' ), 'eps_meta_box_output', 'ost', 'normal', 'high' );

}

/* show on post */
function eps_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_eps_meta_box_nonce', 'eps_meta_box_nonce' ); ?>
  
  <p>
    <label for="eps_url1"><?php _e( 'Episode', 'eps' ); ?>:</label>
    <input class="widefat" type="text" name="eps_url1" id="eps_url1" value="<?php echo eps_get_custom_field( 'eps_url1' ); ?>" size="50" placeholder="Episode" />
    </p>
  
  <p>
    <label for="eps_url2"><?php _e( 'Status', 'eps' ); ?>:</label>
    <input class="widefat" type="text" name="eps_url2" id="eps_url2" value="<?php echo eps_get_custom_field( 'eps_url2' ); ?>" size="50" placeholder="Status" />
    </p>

  <?php
}

/* Save the Meta box values */

function eps_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['eps_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['eps_meta_box_nonce'], 'my_eps_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

    // Save the textfield
  if( isset( $_POST['eps_url1'] ) )
    update_post_meta( $post_id, 'eps_url1', esc_attr( $_POST['eps_url1'] ) );

    // Save the textarea
  if( isset( $_POST['eps_url2'] ) )
    update_post_meta( $post_id, 'eps_url2', esc_attr( $_POST['eps_url2'] ) );
}
add_action( 'save_post', 'eps_meta_box_save' );

/**
 * Metabox Status Streaming
 */
function stream_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}


/* Download Box */

function stream_add_custom_meta_box() {
  add_meta_box( 'stream-meta-box', __( 'Streaming Link', 'stream' ), 'stream_meta_box_output', 'post', 'normal', 'high' );

}

/* show on post */
function stream_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_stream_meta_box_nonce', 'stream_meta_box_nonce' ); ?>
  
  <p>
    <label for="stream_url1"><?php _e( 'Google', 'stream' ); ?>:</label>
    <input class="widefat" type="text" name="stream_url1" id="stream_url1" value="<?php echo stream_get_custom_field( 'stream_url1' ); ?>" size="50" placeholder="Google Drive Video link" />
    </p>

  <p>
    <label for="stream_url2"><?php _e( 'Openload', 'stream' ); ?>:</label>
    <input class="widefat" type="text" name="stream_url2" id="stream_url2" value="<?php echo stream_get_custom_field( 'stream_url2' ); ?>" size="50" placeholder="Openload Video link" />
    </p>
  
  <p>
    <label for="stream_url3"><?php _e( 'MP4upload', 'stream' ); ?>:</label>
    <input class="widefat" type="text" name="stream_url3" id="stream_url3" value="<?php echo stream_get_custom_field( 'stream_url3' ); ?>" size="50" placeholder="MP4upload Video link" />
    </p>

  <?php
}

/* Save the Meta box values */

function stream_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['stream_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['stream_meta_box_nonce'], 'my_stream_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

    // Save the textfield
  if( isset( $_POST['stream_url1'] ) )
    update_post_meta( $post_id, 'stream_url1', esc_attr( $_POST['stream_url1'] ) );

      // Save the textfield
  if( isset( $_POST['stream_url2'] ) )
    update_post_meta( $post_id, 'stream_url2', esc_attr( $_POST['stream_url2'] ) );

    // Save the textarea
  if( isset( $_POST['stream_url3'] ) )
    update_post_meta( $post_id, 'stream_url3', esc_attr( $_POST['stream_url3'] ) );
}
add_action( 'save_post', 'stream_meta_box_save' );