<?php 

//======================
	//Admin menu 
//======================


function megumi_add_admin_page() {
	add_menu_page( 'Megumi Theme Options', 'Kato Setting', 'manage_options', 'megumi_kato', 'megumi_theme_create_page', get_template_directory() . '/img/Kato.png', 120 );
	//add Submenu page
	add_submenu_page( 'megumi_kato', 'Kato Theme Options', 'Setting', 'manage_options', 'megumi_kato', 'megumi_theme_create_page' );
	add_submenu_page( 'megumi_kato', 'Kato Metabox Options', 'Metabox', 'manage_options', 'megumi_katobox', 'megumi_theme_metabox_page' );
	add_submenu_page( 'megumi_kato', 'Kato Post Type', 'Post Type', 'manage_options', 'megumi_postype', 'megumi_post_type' );

}

add_action( 'admin_menu', 'megumi_add_admin_page' );

//Activate custom settings
add_action( 'admin_init', 'megumi_custom_settings' );

function megumi_custom_settings() {

//CPT =custom Post type
	register_setting( 'Kato-post-type', 'custom_batch' );
	register_setting( 'Kato-post-type', 'custom_ost' );
	register_setting( 'Kato-post-type', 'custom_background' );
	
	add_settings_section( 'sunset-theme-options', 'Theme Options', 'sunset_theme_options', 'megumi_postype' );
	
	add_settings_field( 'post-formats', 'Custom Post Type Batch', 'sunset_post_formats', 'megumi_postype', 'sunset-theme-options' );
	add_settings_field( 'custom-header', 'Custom Post Type Ost', 'sunset_custom_header', 'megumi_postype', 'sunset-theme-options' );
	add_settings_field( 'custom-background', 'Custom Post Type Info', 'sunset_custom_background', 'megumi_postype', 'sunset-theme-options' );

//Metabox 
	register_setting( 'kato-metabox-act', 'metabox_480p' );
	register_setting( 'kato-metabox-act', 'metabox_720p' );
	register_setting( 'kato-metabox-act', 'metabox_1080p' );
	register_setting( 'kato-metabox-act', 'metabox_status' );

	
	add_settings_section( 'sunset-theme-options', 'Theme Options', 'kato_metabox_options', 'megumi_katobox' );
	
	add_settings_field( 'post-formats', 'Metabox 480p', 'kato_metabox_480p', 'megumi_katobox', 'sunset-theme-options' );
	add_settings_field( 'custom-header', 'Metabox 720p', 'kato_metabox_720p', 'megumi_katobox', 'sunset-theme-options' );
	add_settings_field( 'custom-kampret', 'Metabox 1080p', 'kato_metabox_1080p', 'megumi_katobox', 'sunset-theme-options' );
	add_settings_field( 'custom-background', 'Metabox Status and Episode', 'kato_metabox_status', 'megumi_katobox', 'sunset-theme-options' );


	register_setting( 'kato-metabox-str', 'metabox_stream' );
	add_settings_section( 'sunset-theme-options', 'Manage Options', 'kato_admin_meta', 'megumi_kato' );
	add_settings_field( 'streaming-link', 'Metabox Streaming', 'kato_metabox_stream', 'megumi_kato', 'sunset-theme-options' );
}

//
function kato_admin_meta() {
	echo 'Ubah Pengaturan Kato Theme dan lainya disini';
}
function kato_metabox_stream() {
	$options = get_option( 'metabox_stream' );
	$checked = ( @$options == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="metabox_stream" name="metabox_stream" value="1" '.$checked.' /> Activate the Metabox Streaming</label>';
}

// Kato activate Metabox
function kato_metabox_options() {
	echo 'Activate and Deactivate specific Theme Support Options';
}

function kato_metabox_status() {
	$options = get_option( 'metabox_status' );
	$checked = ( @$options == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="metabox_status" name="metabox_status" value="1" '.$checked.' /> Activate the Metabox Satus and Episode</label>';
}

function kato_metabox_480p() {
	$options = get_option( 'metabox_480p' );
	$checked = ( @$options == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="metabox_480p" name="metabox_480p" value="1" '.$checked.' /> Activate the Metabox 480p</label>';
}
function kato_metabox_720p() {
	$options = get_option( 'metabox_720p' );
	$checked = ( @$options == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="metabox_720p" name="metabox_720p" value="1" '.$checked.' /> Activate the Metabox 720p</label>';
}
function kato_metabox_1080p() {
	$options = get_option( 'metabox_1080p' );
	$checked = ( @$options == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="metabox_1080p" name="metabox_1080p" value="1" '.$checked.' /> Activate the Metabox 1080p</label>';
}



// Kato activate custom post type
function sunset_theme_options() {
	echo 'Activate and Deactivate specific Theme Support Options';
}

function sunset_post_formats() {
	$options = get_option( 'custom_batch' );
	$checked = ( @$options == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="custom_batch" name="custom_batch" value="1" '.$checked.' /> Activate the Custom Post Type Batch</label>';
}
function sunset_custom_header() {
	$options = get_option( 'custom_ost' );
	$checked = ( @$options == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="custom_ost" name="custom_ost" value="1" '.$checked.' /> Activate the Custom Post Type Ost</label>';
}
function sunset_custom_background() {
	$options = get_option( 'custom_background' );
	$checked = ( @$options == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="custom_background" name="custom_background" value="1" '.$checked.' /> Activate the Custom Post Type Info</label>';
}
//create page/sbpage
function megumi_theme_create_page() {
	require_once( get_template_directory() . '/inc/templates/kato-admin.php' );
}

function megumi_post_type() {
	require_once( get_template_directory() . '/inc/templates/kato-post-type.php' );
}

function megumi_theme_metabox_page() {
	require_once( get_template_directory() . '/inc/templates/metabox-kato.php' );
}