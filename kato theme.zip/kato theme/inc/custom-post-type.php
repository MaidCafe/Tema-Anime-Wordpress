<?php
/*
	
@package sunsettheme
	
	========================
		THEME CUSTOM POST TYPES Batch
	========================
*/

//batch CPT
$batch = get_option( 'custom_batch' );
if( @$batch == 1 ){
	add_action('init', 'cptui_register_my_cpt_batch');
  add_action( 'add_meta_boxes', 'batch1_add_custom_meta_box' );
  add_action( 'add_meta_boxes', 'batch2_add_custom_meta_box' );
}

//ost CPT
$ost = get_option( 'custom_ost' );
if( @$ost == 1 ){
	add_action('init', 'cptui_register_my_cpt_ost');
  add_action( 'add_meta_boxes', 'ost_add_custom_meta_box' );
}

/* Batch CPT */

function cptui_register_my_cpt_batch() {
register_post_type('batch', array(
'label' => 'Batch',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => false,
'rewrite' => array('slug' => 'Batch', 'with_front' => true),
'query_var' => true,
'supports' => array('title','editor','custom-fields','revisions','thumbnail','author','post-formats','categories'),
'labels' => array (
  'name' => 'Batch List',
  'singular_name' => 'Batch List',
  'menu_name' => 'Batch List',
  'add_new' => 'Add Batch',
  'add_new_item' => 'Add New Batch',
  'edit' => 'Edit',
  'edit_item' => 'Edit Batch',
  'new_item' => 'New Batch',
  'view' => 'View Batch',
  'view_item' => 'View Batch',
  'search_items' => 'Search Batch',
  'not_found' => 'No Batch Found',
  'not_found_in_trash' => 'No Batch Found in Trash',
  'parent' => 'Parent Batch',
),
'public' => true,
'has_archive' => true,
) )
; 
register_taxonomy_for_object_type( 'category', 'batch' );
}


//Ost CPT
function cptui_register_my_cpt_ost() {
register_post_type('ost', array(
'label' => 'Ost',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => false,
'rewrite' => array('slug' => 'Ost', 'with_front' => true),
'query_var' => true,
'supports' => array('title','editor','custom-fields','revisions','thumbnail','author','post-formats','categories'),
'labels' => array (
  'name' => 'Ost List',
  'singular_name' => 'Ost List',
  'menu_name' => 'Ost List',
  'add_new' => 'Add Ost',
  'add_new_item' => 'Add New Ost',
  'edit' => 'Edit',
  'edit_item' => 'Edit Ost',
  'new_item' => 'New Ost',
  'view' => 'View Ost',
  'view_item' => 'View Ost',
  'search_items' => 'Search Ost',
  'not_found' => 'No Ost Found',
  'not_found_in_trash' => 'No Ost Found in Trash',
  'parent' => 'Parent Ost',
),
'public' => true,
'has_archive' => true,
) )
; 
register_taxonomy_for_object_type( 'category', 'ost' );
}

/**
 * Metabox 480pbatch
 */
function batch1_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}
/* Download Box */

function batch1_add_custom_meta_box() {
  add_meta_box( 'batch1-meta-box', __( '480p Link', 'batch1' ), 'batch1_meta_box_output', 'batch', 'normal', 'high' );
}

/* show on post */
function batch1_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_batch1_meta_box_nonce', 'batch1_meta_box_nonce' ); ?>
  
  <p>
    <label for="batch1_url1"><?php _e( 'Link 1', 'batch1' ); ?>:</label>
    <input type="text" name="batch1_tittle1" id="batch1_tittle1" value="<?php echo batch1_get_custom_field( 'batch1_tittle1' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch1_url1" id="batch1_url1" value="<?php echo batch1_get_custom_field( 'batch1_url1' ); ?>" size="50" placeholder="Link Download" />
    </p>
  
  <p>
    <label for="batch1_url2"><?php _e( 'Link 2', 'batch1' ); ?>:</label>
    <input type="text" name="batch1_tittle2" id="batch1_tittle2" value="<?php echo batch1_get_custom_field( 'batch1_tittle2' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch1_url2" id="batch1_url2" value="<?php echo batch1_get_custom_field( 'batch1_url2' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="batch1_url3"><?php _e( 'Link 3', 'batch1' ); ?>:</label>
    <input type="text" name="batch1_tittle3" id="batch1_tittle3" value="<?php echo batch1_get_custom_field( 'batch1_tittle3' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch1_url3" id="batch1_url3" value="<?php echo batch1_get_custom_field( 'batch1_url3' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="batch1_url4"><?php _e( 'Link 4', 'batch1' ); ?>:</label>
    <input type="text" name="batch1_tittle4" id="batch1_tittle4" value="<?php echo batch1_get_custom_field( 'batch1_tittle4' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch1_url4" id="batch1_url4" value="<?php echo batch1_get_custom_field( 'batch1_url4' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="batch1_url5"><?php _e( 'Link 5', 'batch1' ); ?>:</label>
    <input type="text" name="batch1_tittle5" id="batch1_tittle5" value="<?php echo batch1_get_custom_field( 'batch1_tittle5' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch1_url5" id="batch1_url5" value="<?php echo batch1_get_custom_field( 'batch1_url5' ); ?>" size="50" placeholder="Link Download" />
    </p>
  <?php
}

/* Save the Meta box values */

function batch1_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['batch1_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['batch1_meta_box_nonce'], 'my_batch1_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['batch1_url1'] ) )
    update_post_meta( $post_id, 'batch1_url1', esc_attr( $_POST['batch1_url1'] ) );

    // Save the textarea
  if( isset( $_POST['batch1_url2'] ) )
    update_post_meta( $post_id, 'batch1_url2', esc_attr( $_POST['batch1_url2'] ) );

    // Save the url
  if( isset( $_POST['batch1_url3'] ) )
    update_post_meta( $post_id, 'batch1_url3', esc_attr( $_POST['batch1_url3'] ) );

      // Save the url
  if( isset( $_POST['batch1_url4'] ) )
    update_post_meta( $post_id, 'batch1_url4', esc_attr( $_POST['batch1_url4'] ) );

      // Save the url
  if( isset( $_POST['batch1_url5'] ) )
    update_post_meta( $post_id, 'batch1_url5', esc_attr( $_POST['batch1_url5'] ) );
        // Save the url
  if( isset( $_POST['batch1_tittle1'] ) )
    update_post_meta( $post_id, 'batch1_tittle1', esc_attr( $_POST['batch1_tittle1'] ) );

  if( isset( $_POST['batch1_tittle2'] ) )
    update_post_meta( $post_id, 'batch1_tittle2', esc_attr( $_POST['batch1_tittle2'] ) );

  if( isset( $_POST['batch1_tittle3'] ) )
    update_post_meta( $post_id, 'batch1_tittle3', esc_attr( $_POST['batch1_tittle3'] ) );

 if( isset( $_POST['batch1_tittle4'] ) )
    update_post_meta( $post_id, 'batch1_tittle4', esc_attr( $_POST['batch1_tittle4'] ) );

  if( isset( $_POST['batch1_tittle5'] ) )
    update_post_meta( $post_id, 'batch1_tittle5', esc_attr( $_POST['batch1_tittle5'] ) );
}
add_action( 'save_post', 'batch1_meta_box_save' );

/**
 * Metabox 720p batch
 */
function batch2_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}
/* Download Box */

function batch2_add_custom_meta_box() {
  add_meta_box( 'batch2-meta-box', __( '720p Link', 'batch2' ), 'batch2_meta_box_output', 'batch', 'normal', 'high' );
}

/* show on post */
function batch2_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_batch2_meta_box_nonce', 'batch2_meta_box_nonce' ); ?>
  
  <p>
    <label for="batch2_url1"><?php _e( 'Link 1', 'batch2' ); ?>:</label>
    <input type="text" name="batch2_tittle1" id="batch2_tittle1" value="<?php echo batch2_get_custom_field( 'batch2_tittle1' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch2_url1" id="batch2_url1" value="<?php echo batch2_get_custom_field( 'batch2_url1' ); ?>" size="50" placeholder="Link Download" />
    </p>
  
  <p>
    <label for="batch2_url2"><?php _e( 'Link 2', 'batch2' ); ?>:</label>
    <input type="text" name="batch2_tittle2" id="batch2_tittle2" value="<?php echo batch2_get_custom_field( 'batch2_tittle2' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch2_url2" id="batch2_url2" value="<?php echo batch2_get_custom_field( 'batch2_url2' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="batch2_url3"><?php _e( 'Link 3', 'batch2' ); ?>:</label>
    <input type="text" name="batch2_tittle3" id="batch2_tittle3" value="<?php echo batch2_get_custom_field( 'batch2_tittle3' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch2_url3" id="batch2_url3" value="<?php echo batch2_get_custom_field( 'batch2_url3' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="batch2_url4"><?php _e( 'Link 4', 'batch2' ); ?>:</label>
    <input type="text" name="batch2_tittle4" id="batch2_tittle4" value="<?php echo batch2_get_custom_field( 'batch2_tittle4' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch2_url4" id="batch2_url4" value="<?php echo batch2_get_custom_field( 'batch2_url4' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="batch2_url5"><?php _e( 'Link 5', 'batch2' ); ?>:</label>
    <input type="text" name="batch2_tittle5" id="batch2_tittle5" value="<?php echo batch2_get_custom_field( 'batch2_tittle5' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="batch2_url5" id="batch2_url5" value="<?php echo batch2_get_custom_field( 'batch2_url5' ); ?>" size="50" placeholder="Link Download" />
    </p>
  <?php
}

/* Save the Meta box values */

function batch2_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['batch2_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['batch2_meta_box_nonce'], 'my_batch2_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['batch2_url1'] ) )
    update_post_meta( $post_id, 'batch2_url1', esc_attr( $_POST['batch2_url1'] ) );

    // Save the textarea
  if( isset( $_POST['batch2_url2'] ) )
    update_post_meta( $post_id, 'batch2_url2', esc_attr( $_POST['batch2_url2'] ) );

    // Save the url
  if( isset( $_POST['batch2_url3'] ) )
    update_post_meta( $post_id, 'batch2_url3', esc_attr( $_POST['batch2_url3'] ) );

      // Save the url
  if( isset( $_POST['batch2_url4'] ) )
    update_post_meta( $post_id, 'batch2_url4', esc_attr( $_POST['batch2_url4'] ) );

      // Save the url
  if( isset( $_POST['batch2_url5'] ) )
    update_post_meta( $post_id, 'batch2_url5', esc_attr( $_POST['batch2_url5'] ) );
        // Save the url
  if( isset( $_POST['batch2_tittle1'] ) )
    update_post_meta( $post_id, 'batch2_tittle1', esc_attr( $_POST['batch2_tittle1'] ) );

  if( isset( $_POST['batch2_tittle2'] ) )
    update_post_meta( $post_id, 'batch2_tittle2', esc_attr( $_POST['batch2_tittle2'] ) );

  if( isset( $_POST['batch2_tittle3'] ) )
    update_post_meta( $post_id, 'batch2_tittle3', esc_attr( $_POST['batch2_tittle3'] ) );

 if( isset( $_POST['batch2_tittle4'] ) )
    update_post_meta( $post_id, 'batch2_tittle4', esc_attr( $_POST['batch2_tittle4'] ) );

  if( isset( $_POST['batch2_tittle5'] ) )
    update_post_meta( $post_id, 'batch2_tittle5', esc_attr( $_POST['batch2_tittle5'] ) );
}
add_action( 'save_post', 'batch2_meta_box_save' );


/**
 * Metabox Ost
 */
function ost_get_custom_field( $value ) {
  global $post;

    $custom_field = get_post_meta( $post->ID, $value, true );
    if ( !empty( $custom_field ) )
      return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );

    return false;
}
/* Download Box */

function ost_add_custom_meta_box() {
  add_meta_box( 'ost-meta-box', __( 'Ost Link', 'ost' ), 'ost_meta_box_output', 'ost', 'normal', 'high' );
}

/* show on post */
function ost_meta_box_output( $object, $box ) {
  // create a nonce field
  wp_nonce_field( 'my_ost_meta_box_nonce', 'ost_meta_box_nonce' ); ?>
  
  <p>
    <label for="ost_url1"><?php _e( 'Link 1', 'ost' ); ?>:</label>
    <input type="text" name="ost_tittle1" id="ost_tittle1" value="<?php echo ost_get_custom_field( 'ost_tittle1' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="ost_url1" id="ost_url1" value="<?php echo ost_get_custom_field( 'ost_url1' ); ?>" size="50" placeholder="Link Download" />
    </p>
  
  <p>
    <label for="ost_url2"><?php _e( 'Link 2', 'ost' ); ?>:</label>
    <input type="text" name="ost_tittle2" id="ost_tittle2" value="<?php echo ost_get_custom_field( 'ost_tittle2' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="ost_url2" id="ost_url2" value="<?php echo ost_get_custom_field( 'ost_url2' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="ost_url3"><?php _e( 'Link 3', 'ost' ); ?>:</label>
    <input type="text" name="ost_tittle3" id="ost_tittle3" value="<?php echo ost_get_custom_field( 'ost_tittle3' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="ost_url3" id="ost_url3" value="<?php echo ost_get_custom_field( 'ost_url3' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="ost_url4"><?php _e( 'Link 4', 'ost' ); ?>:</label>
    <input type="text" name="ost_tittle4" id="ost_tittle4" value="<?php echo ost_get_custom_field( 'ost_tittle4' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="ost_url4" id="ost_url4" value="<?php echo ost_get_custom_field( 'ost_url4' ); ?>" size="50" placeholder="Link Download" />
    </p>

   <p>
    <label for="ost_url5"><?php _e( 'Link 5', 'ost' ); ?>:</label>
    <input type="text" name="ost_tittle5" id="ost_tittle5" value="<?php echo ost_get_custom_field( 'ost_tittle5' ); ?>" size="18" placeholder="Nama Situs" />
    <br />
    <input class="widefat" type="text" name="ost_url5" id="ost_url5" value="<?php echo ost_get_custom_field( 'ost_url5' ); ?>" size="50" placeholder="Link Download" />
    </p>
  <?php
}

/* Save the Meta box values */

function ost_meta_box_save( $post_id ) {
  // Stop the script when doing autosave
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

  // Verify the nonce. If insn't there, stop the script
  if( !isset( $_POST['ost_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['ost_meta_box_nonce'], 'my_ost_meta_box_nonce' ) ) return;

  // Stop the script if the user does not have edit permissions
  if( !current_user_can( 'edit_post', get_the_id() ) ) return;

  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );

    // Save the textfield
  if( isset( $_POST['ost_url1'] ) )
    update_post_meta( $post_id, 'ost_url1', esc_attr( $_POST['ost_url1'] ) );

    // Save the textarea
  if( isset( $_POST['ost_url2'] ) )
    update_post_meta( $post_id, 'ost_url2', esc_attr( $_POST['ost_url2'] ) );

    // Save the url
  if( isset( $_POST['ost_url3'] ) )
    update_post_meta( $post_id, 'ost_url3', esc_attr( $_POST['ost_url3'] ) );

      // Save the url
  if( isset( $_POST['ost_url4'] ) )
    update_post_meta( $post_id, 'ost_url4', esc_attr( $_POST['ost_url4'] ) );

      // Save the url
  if( isset( $_POST['ost_url5'] ) )
    update_post_meta( $post_id, 'ost_url5', esc_attr( $_POST['ost_url5'] ) );
        // Save the url
  if( isset( $_POST['ost_tittle1'] ) )
    update_post_meta( $post_id, 'ost_tittle1', esc_attr( $_POST['ost_tittle1'] ) );

  if( isset( $_POST['ost_tittle2'] ) )
    update_post_meta( $post_id, 'ost_tittle2', esc_attr( $_POST['ost_tittle2'] ) );

  if( isset( $_POST['ost_tittle3'] ) )
    update_post_meta( $post_id, 'ost_tittle3', esc_attr( $_POST['ost_tittle3'] ) );

 if( isset( $_POST['ost_tittle4'] ) )
    update_post_meta( $post_id, 'ost_tittle4', esc_attr( $_POST['ost_tittle4'] ) );

  if( isset( $_POST['ost_tittle5'] ) )
    update_post_meta( $post_id, 'ost_tittle5', esc_attr( $_POST['ost_tittle5'] ) );
}
add_action( 'save_post', 'ost_meta_box_save' );