<h1>Kato Theme Options</h1>
<form method="post" action="options.php" class="sunset-general-form">
	<?php settings_fields( 'kato-metabox-str' ); ?>
	<?php do_settings_sections( 'megumi_kato' ); ?>
	<?php submit_button(); ?>
</form>