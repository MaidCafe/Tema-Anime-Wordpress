<h1>Kato Metabox</h1>
<?php settings_errors(); ?>

<form method="post" action="options.php" class="sunset-general-form">
	<?php settings_fields( 'kato-metabox-act' ); ?>
	<?php do_settings_sections( 'megumi_katobox' ); ?>
	<?php submit_button(); ?>
</form>