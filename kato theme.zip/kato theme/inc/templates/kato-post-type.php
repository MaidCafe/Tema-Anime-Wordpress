<h1>Kato Post Type</h1>
<?php settings_errors(); ?>

<form method="post" action="options.php" class="sunset-general-form">
	<?php settings_fields( 'Kato-post-type' ); ?>
	<?php do_settings_sections( 'megumi_postype' ); ?>
	<?php submit_button(); ?>
</form>