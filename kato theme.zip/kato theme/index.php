<?php get_header(); ?>

<div id="kasumigaoka">
<div id="antblock">
<div class="left">

<div class="right">
</div></div></div>
<div class="clear"></div>
<style>
/******* GENRES NAVIGATION ********/
.allinfo {margin: 0px auto 5px;}
.allinfo h2 {background:#b366ff;font-size: 12px;margin-top: 0px;float: left;padding: 3px 8px;line-height: 20px;color: #fff;}
.allinfo ul {width:100%;margin: 0;padding: 0px;background: #f1f1f1;list-style: none;}
.allinfo ul li {float: left;line-height:26px;padding:0px 3px;}
.allinfo ul li a {color: #555;font-weight: bold;font-size: 11px;}
.allinfo ul li a:hover{text-decoration:underline;}
</style>
<div class="allinfo">
<?php
//list terms in a given taxonomy
$taxonomy = 'genre';
$tax_terms = get_terms($taxonomy,'number=17');
?>
<ul><h2>Genre: </h2>
<?php
foreach ($tax_terms as $tax_term) {
echo '<li>' . '<a href="' . esc_attr(get_term_link($tax_term, $taxonomy)) . '" title="' . sprintf( __( "View all posts in %s" ), $tax_term->name ) . '" ' . '>' . $tax_term->name.'</a></li>';
}
?>
<div class="clear"></div>
</ul>
</div>
<div class="clear"></div>

<! -- ATASAN -- >

<div class="katobody col-md-8 col-sm-8 col-xs-12">

<! -- PUSAT POSTINGAN -- >

<div class="megumi">
<h1 class='arc'>Recent Update</h1>
<div class="megumi-flex row row-flex">
<?php if ( have_posts() ) : ?>
<?php
if( is_home() ){
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
query_posts( array('post_type'=>array(
'post','batch', 'ost' ),'paged'=>$paged ) );
}
?>
<?php while ( have_posts() ) : the_post(); ?>
<?php get_template_part('articles'); ?>
<?php endwhile; ?>
</div><div class="clear"></div>
<div class="clear"></div>

<!-- pagination -->

<div class="pagination">
<?php pagenavi(); ?>
</div>
<div class='clear'></div>

<div class="ongoingrekom">
<h1 class='arc'>Featured Series</h1>
<div class="listongo row">
<?php
$myposts = array(
    'showposts' => 5,
    'post_type' => 'anime',
    'orderby' => 'rand',
    'tax_query' => array(
        array(
        'taxonomy' => 'status',
        'field' => 'slug',
        'terms' => 'finished')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
<div class="boxreko col-md-3 col-sm-3 col-xs-6">
<div class="ongogambar"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(420,200)); }
else {
 echo '<img height="200" width="100%" src="',get_template_directory_uri(),'/img/megumi.png" alt="Thumbnail no image">';}?><h2><?php the_title(); ?></h2></a></div>
</div>
<?php endwhile; ?>
</div>
<div class="clear"></div>
</div>

<div id="rekommov"><h1 class='moviearc'>Movie</h1><div class="arch">Movie List</div></div>
<div class="rekomendasi">
<div class="listreko row">
<?php
$myposts = array(
    'showposts' => 4,
    'post_type' => 'anime',
    'orderby' => 'rand',
    'tax_query' => array(
        array(
        'taxonomy' => 'type',
        'field' => 'slug',
        'terms' => 'movie')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
<div class="boxreko col-md-3 col-sm-3 col-xs-6">
<div class="gambar"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(420,200)); }
else {
 echo '<img height="200" width="100%" src="',get_template_directory_uri(),'/img/megumi.png" alt="Thumbnail no image">';}?><h2><?php the_title(); ?></h2></a></div>
</div>
<?php endwhile; ?>
</div>
<div class="clear"></div>
</div>
<div id="rekommov"><h1 class='moviearc'>Special</h1><div class="arch">Special List</div></div>
<div class="rekomendasi">
<div class="listreko row">
<?php
$myposts = array(
    'showposts' => 4,
    'post_type' => 'anime',
    'orderby' => 'rand',
    'tax_query' => array(
        array(
        'taxonomy' => 'type',
        'field' => 'slug',
        'terms' => 'special')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
<div class="boxreko col-md-3 col-sm-3 col-xs-6">
<div class="gambar"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(420,200)); }
else {
 echo '<img height="200" width="100%" src="',get_template_directory_uri(),'/img/megumi.png" alt="Thumbnail no image">';}?><h2><?php the_title(); ?></h2></a></div>
</div>
<?php endwhile; ?>
</div>
<div class="clear"></div>
</div>
<div id="rekommov"><h1 class='moviearc'>On-going</h1><div class="arch">On-going List</div></div>
<div class="rekomendasi">
<div class="listreko row">
<?php
$myposts = array(
    'showposts' => 4,
    'post_type' => 'anime',
    'orderby' => 'rand',
    'tax_query' => array(
        array(
        'taxonomy' => 'status',
        'field' => 'slug',
        'terms' => 'ongoing')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
<div class="boxreko col-md-3 col-sm-3 col-xs-6">
<div class="gambar"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(array(420,200)); }
else {
 echo '<img height="200" width="100%" src="',get_template_directory_uri(),'/img/megumi.png" alt="Thumbnail no image">';}?><h2><?php the_title(); ?></h2></a></div>
</div>
<?php endwhile; ?>
</div>
<div class="clear"></div>
</div>

<!-- No posts found -->
<?php endif; ?>
</div>


</div>

<?php get_template_part('sidebar'); ?>
</div></div></div>

<?php get_footer(); ?>