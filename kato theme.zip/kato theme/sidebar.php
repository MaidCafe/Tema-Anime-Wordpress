<div id="sidebar" class="col-md-4 col-sm-4 col-xs-12">
<div class="rez">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
<?php endif; ?>
<div class="preks"><h3><b>Popular Series</b></div>
<?php
$popularpost = new WP_Query( array( 'post_type' => anime, 'posts_per_page' => 5, 'meta_key' => 'wpb_post_views_count', 'orderby' => 'meta_value_num' ) );
while ( $popularpost->have_posts() ) : $popularpost->the_post(); ?>
<div class='polarpost'>
<div class='polargambar'><?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?></div>
<div class="polarjdl"><h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2> 
<div class="polargenre"><?php echo get_the_term_list( $post->ID, 'genre', 'Genre: ', ', ', '' ); ?></div>
</div>
</div>
<?php endwhile; ?><!--Selesai -->

</div>
</div>