<?php get_header(); ?>


<div id="kasumigaoka">
<div id="antblock">
<div class="left">

<div class="clear"></div>
<div class="right">
</div></div></div>
<div class="clear"></div>
<div class="katobody">
<div class="bodo">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class='titler'>
<h1 class="ttl"><?php the_title(); ?></h1>
<div class='kategori'>
<?php
          setCrunchifyPostViews(get_the_ID());
?>
Released on <?php the_time('jS F, Y'); ?> , <i class='fa fa-eye'></i></b> <?php
          echo getCrunchifyPostViews(get_the_ID());
?> 
</div>
</div>

<div class="clear"></div>

<div id='switch'>
<span class='lightSwitcher' id='checkbox'>
<?php echo sagirih_pagination() ?>
<label data-off='OFF' data-on='ON'></label>
</span>
</div>
<div class='outer' ng-app='tabs'>
  <div class='tabs' ng-controller='shift_tabs as shift'>
    <div class='tab-buttons' ng-init='shift.makeShift(1)'>
      <button ng-click='shift.makeShift(1)' ng-class='{active:shift.isActive(1)}'>Google</button>
      <button ng-click='shift.makeShift(2)' ng-class='{active:shift.isActive(2)}'>Openload</button>
      <button ng-click='shift.makeShift(3)' ng-class='{active:shift.isActive(3)}'>MP4Upload</button>
    </div>
    <div class='tab-content'>
      <div ng-show='shift.isActive(1)'>
<iframe  src="<?php echo get_post_meta($post->ID, 'stream_url1', true);?>" scrolling="no" frameborder="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe></div>
      <div ng-show='shift.isActive(2)'><iframe  src="<?php echo get_post_meta($post->ID, 'stream_url2', true);?>" scrolling="no" frameborder="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe></div>
      <div ng-show='shift.isActive(3)'><iframe  src="<?php echo get_post_meta($post->ID, 'stream_url3', true);?>" scrolling="no" frameborder="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe></div>
    </div>
  </div>
</div>
<div class='titler'>
<center>
<h1 class="ttl"> <i class="fa fa-info-circle" aria-hidden="true"></i>nfo Anime </h1>
</center>
<div class='kategori'>
</div>
</div>
<div class="clear"></div>
<?php echo sagirih_info() ?>
<div class="clear"></div>
<hr />
<div class='titler'>
<center>
<h1 class="ttl">Link Download</h1>
<i class='fa fa-download'></i>
</center>
<div class='kategori'>
<center>
Download Via Streaming Kanan Atas Gan NO ADS 100% iklan muncul lapor sini....!!
</center>
<center>
Credit or Subbed by : Tertera dalam Video <br>
Samehadaku, Naruciha, Tiramisub, Awsub, DLL
</center>
</div>
</div>
<div class="katodl">
<div class="katotl"><h5><?php the_title(); ?>  480p </h5></div>
<div class="katourl">
<h6>
<a href="<?php echo get_post_meta($post->ID, 'kato_url1', true);?>"><?php echo get_post_meta($post->ID, 'kato_tittle1', true);?></a>
     |    
<a href="<?php echo get_post_meta($post->ID, 'kato_url2', true);?>"><?php echo get_post_meta($post->ID, 'kato_tittle2', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'kato_url3', true);?>"><?php echo get_post_meta($post->ID, 'kato_tittle3', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'kato_url4', true);?>"><?php echo get_post_meta($post->ID, 'kato_tittle4', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'kato_url5', true);?>"><?php echo get_post_meta($post->ID, 'kato_tittle5', true);?></a>
  |  
</h6>
</div>
<div class="katotl"><h5><?php the_title(); ?>  720p </h5></div>
<div class="katourl">
<h6>
<a href="<?php echo get_post_meta($post->ID, 'megumi_url1', true);?>"><?php echo get_post_meta($post->ID, 'megumi_tittle1', true);?></a>
     |    
<a href="<?php echo get_post_meta($post->ID, 'megumi_url2', true);?>"><?php echo get_post_meta($post->ID, 'megumi_tittle2', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'megumi_url3', true);?>"><?php echo get_post_meta($post->ID, 'megumi_tittle3', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'megumi_url4', true);?>"><?php echo get_post_meta($post->ID, 'megumi_tittle4', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'megumi_url5', true);?>"><?php echo get_post_meta($post->ID, 'megumi_tittle5', true);?></a>
  |  
</h6>
</div>
<div class="katotl"><h5><?php the_title(); ?>  1080p </h5></div>
<div class="katourl">
<h6>
<a href="<?php echo get_post_meta($post->ID, 'kasumi_url1', true);?>"><?php echo get_post_meta($post->ID, 'kasumi_tittle1', true);?></a>
     |    
<a href="<?php echo get_post_meta($post->ID, 'kasumi_url2', true);?>"><?php echo get_post_meta($post->ID, 'kasumi_tittle2', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'kasumi_url3', true);?>"><?php echo get_post_meta($post->ID, 'kasumi_tittle3', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'kasumi_url4', true);?>"><?php echo get_post_meta($post->ID, 'kasumi_tittle4', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'kasumi_url5', true);?>"><?php echo get_post_meta($post->ID, 'kasumi_tittle5', true);?></a>
  |  
</h6>
</div>
</div></div>
<div class="clear">
<br>
</div>

<div class='socialshare'>
<a href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank" class="sfb"><span class="dashicons dashicons-facebook-alt"></span> Facebook</a>
<a href="http://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank" class="stw"> <span class="dashicons dashicons-twitter"></span> Twitter</a>
<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" class="sgp"><span class="dashicons dashicons-googleplus"></span> Google+</a>
</div>
<div class="animeinfo">
      <div class="left">
<?php get_template_part('relatedpost'); ?>
<?php endwhile; endif; ?>
</div>
<div class="right">
<script data-cfasync="false" type="text/javascript" src="https://www.adnetworkperformance.com/a/display.php?r=1578613"></script>
</div></div>
<div class="clear"></div>
<div class="commentarea">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php echo get_post_meta($post->ID, "embed", true); ?>
<?php comments_template(); ?>
<?php endwhile; endif; ?>
</div></div>

<?php get_template_part('sidebar'); ?>
</div></div>
<?php get_footer(); ?>