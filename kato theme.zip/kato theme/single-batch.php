<?php
/*
Template Name: Batch Anime
*/
?>
<?php get_header(); ?>

<div id="kasumigaoka">
<div id="antblock">
<div class="left">

<div class="right">
</div></div></div>
<div class="clear"></div>
<div class="katobody">
<div class="bodo">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class='titler'>
<h1 class="ttl"><?php the_title(); ?></h1>
<div class='kategori'>
<?php
          setCrunchifyPostViews(get_the_ID());
?>
Released on <?php the_time('jS F, Y'); ?> , <i class='fa fa-eye'></i></b> <?php
          echo getCrunchifyPostViews(get_the_ID());
?> 
</div>
</div>
<div class="text">
<?php the_content(); ?>
</div>
<hr />
<div class='titler'>
<center>
<h1 class="ttl">Link Download</h1>
<i class='fa fa-download'></i>
</center>
<div class='kategori'>
</div>
</div>
<div class="katodl">
<div class="katotl"><h5><?php the_title(); ?>  480p </h5></div>
<div class="katourl">
<h6>
<a href="<?php echo get_post_meta($post->ID, 'batch1_url1', true);?>"><?php echo get_post_meta($post->ID, 'batch1_tittle1', true);?></a>
     |    
<a href="<?php echo get_post_meta($post->ID, 'batch1_url2', true);?>"><?php echo get_post_meta($post->ID, 'batch1_tittle2', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'batch1_url3', true);?>"><?php echo get_post_meta($post->ID, 'batch1_tittle3', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'batch1_url4', true);?>"><?php echo get_post_meta($post->ID, 'batch1_tittle4', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'batch1_url5', true);?>"><?php echo get_post_meta($post->ID, 'batch1_tittle5', true);?></a>
  |  
</h6>
</div>
<div class="katotl"><h5><?php the_title(); ?>  720p </h5></div>
<div class="katourl">
<h6>
<a href="<?php echo get_post_meta($post->ID, 'batch2_url1', true);?>"><?php echo get_post_meta($post->ID, 'batch2_tittle1', true);?></a>
     |    
<a href="<?php echo get_post_meta($post->ID, 'batch2_url2', true);?>"><?php echo get_post_meta($post->ID, 'batch2_tittle2', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'batch2_url3', true);?>"><?php echo get_post_meta($post->ID, 'batch2_tittle3', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'batch2_url4', true);?>"><?php echo get_post_meta($post->ID, 'batch2_tittle4', true);?></a>
  |  
<a href="<?php echo get_post_meta($post->ID, 'batch2_url5', true);?>"><?php echo get_post_meta($post->ID, 'batch2_tittle5', true);?></a>
  |  
</h6>
</div>
</div>
</div>
<div class="clear"></div>

<div class='socialshare'>
<a href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank" class="sfb"><span class="dashicons dashicons-facebook-alt"></span> Facebook</a>
<a href="http://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank" class="stw"> <span class="dashicons dashicons-twitter"></span> Twitter</a>
<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" class="sgp"><span class="dashicons dashicons-googleplus"></span> Google+</a>
</div>

<div class="clear"></div>
<div class="ptcklan">
<div class="left">
<img src="http://animesearch.net/wp-content/uploads/2017/01/post-iklan.png"/></div>
<div class="right">
<img src="http://animesearch.net/wp-content/uploads/2017/01/post-iklan.png"/></div>
</div>

<div class="clear"></div>
<div class="animeinfo">
      <div class="left">

<?php 
$category = get_the_category();
$firstCategory = $category[0]->cat_name;
$myposts = array(
    'showposts' => 1,
    'post_type' => 'anime',
    'orderby' => '',
    'tax_query' => array(
        array(
        'taxonomy' => 'name',
        'field' => 'slug',
        'terms' => '$firstCategory')
    )
);
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query($myposts);
?>
<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?> 
    <span><?php the_title(); ?></span> 
    <span><?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?></span> 
    <?php wp_reset_query(); ?>

    <?php endwhile; ?>
             </div>

      <div class="right">
      <?php
$popularpost = new WP_Query( array( 'post_type' => anime, 'posts_per_page' => 4 , 'orderby' => 'rand') );
while ( $popularpost->have_posts() ) : $popularpost->the_post(); ?>
<ul class="related">
<li>
<div class='gambarg'>
<div class='limiter'>
<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?>
</div></div>
<div class='rights'>
<div class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<div class="cat"><?php echo get_the_term_list( $post->ID, 'genre', 'Genre: ', ', ', '' ); ?></div>
</div>
</div>
</li>
</ul>

<?php endwhile; ?><!--Selesai -->
</div>

          <div class="clear"></div>
                        <div class="sinop"><p style="text-align: justify;">Dalam olahraga rugby tak ada yang namanya ace striker, tak ada yang namanya pemukul keempat, lalu siapa yang menjadi bintang tim rugby?</p>
<p style="text-align: justify;">Cerita bermula saat upacara masuk di SMA Kanagawa di mana Kenji Gion seorang anak SMA bertubuh kecil namun bertekad kuat bergabung dengan klub rugby. Dia bergabung dengan klub bersama teman sekelasnya yang bernama Iwashimizu yang memiliki masa lalu rumit dan menjadi kapten pengganti, dia sangat peduli pada anggota klubnya. Namun tetap saja yang menjadi kapten adalah Sekizan yang memiliki kekuatan luar biasa namun ia sulit untuk bermain secara tim. Dengan kepribadian serta fisik yang berbeda-beda, tim mereka harus berusaha bekerja sama serta tumbuh bersama sehingga mereka bisa menjadi tim rugby terbaik.</p>
</div>
</div>
<div class="clear"></div>
</div>
<?php endwhile; endif; ?>
<?php get_template_part('sidebar'); ?>
</div></div>
<?php get_footer(); ?>