<?php get_header(); ?>
<br><br>
<center><h1>Anime yang Anda Cari tidak Ditemukan</h1></center>
<br><br>
<?php get_footer(); ?>