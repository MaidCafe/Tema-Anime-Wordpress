<div class="ls">
<div class="img">
<div class="ltr">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { ?><?php the_post_thumbnail('thumbnail',array('title' => ''.get_the_title().'')); ?> <?php } else { ?><img src="<?php echo get_image(); ?>" title="<?php the_title(); ?>" alt="<?php the_title(); ?>" /><?php } ?></a>
</div>
</div>
<div class="nf">
<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="th">Kateogri : <?php the_category(', ') ?> <br> Rilis: <?php the_time('j F Y'); ?>, <br>Posted By : <?php the_author(); ?></div>
</div>
</div>