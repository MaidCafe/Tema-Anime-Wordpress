<?php moe_footer(); ?>
<?php wp_footer(); ?>
<script type="text/javascript" src="http://imeshort.cf/safelink.js"></script>
<script type="text/javascript">
protected_links = "facebook.com,google.com"; 
auto_safelink();
</script> 
</body>
</html>