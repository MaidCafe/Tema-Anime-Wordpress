<?php
include 'inc/widget.php';
include 'inc/custom.php';
if ( function_exists('register_sidebar') )
   register_sidebar(array(
    	'name' => 'Sidebar Right',
        'before_widget' => '<div class="blc">',
        'after_widget' => '</div>',
        'before_title' => '<h3><span>',
        'after_title' => '</span><i></i></h3>',
    ));

add_action( 'init', 'register_my_menus' );

function register_my_menus() {
register_nav_menus(
array(
'main' => __( 'Header Menu' ),
'bottom' => __( 'Bottom Menu' )
)
);}
?>