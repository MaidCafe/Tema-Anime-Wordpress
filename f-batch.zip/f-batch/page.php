<?php get_header(); ?>
<div id="content">
<div class="postsbody">
<div class="ctn">
<?php if ( function_exists('yoast_breadcrumb') ) 
{yoast_breadcrumb('<p id="breadcrumbs">','</p>');} ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h1 class="ttl"><?php the_title(); ?></h1>
<div class="pst">
<?php the_content(); ?>
</div>
</div>
<?php endwhile; endif; ?>
</div>

<?php include (TEMPLATEPATH . '/sidebar_right.php'); ?>
</div>

<?php get_footer(); ?>