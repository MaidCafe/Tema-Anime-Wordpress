<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title( '–', true, 'right' ); ?></title>
<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
<meta name="google-site-verification" content="8SVOO-fRtuAsxHjgPXdT6IDgtHs_PpJhexvmFh8Kzuw" />
</head>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" />
<body>
<div id="wrap">

<header id="header">
<div class="logo"><img src="https://3.bp.blogspot.com/-W0OsZQJ0B7Q/WGqrH-uYmZI/AAAAAAAAbp4/QD_tJPURAs8EgZBIuqt_ozMjTraG0ZxwgCLcB/s1600/knBOZ1483386229-min.jpg" style="
  
"></div>
</header>  
<nav id="main-menu">
<?php 
ob_start();
$nav_menu = wp_nav_menu(array('theme_location'=>'main', 'container'=>'', 'fallback_cb' => '', 'echo' => 0)); 
if(empty($nav_menu))
$nav_menu = '<ul>'.wp_list_categories(array('show_option_all'=>__('Home', 'dp'), 'title_li'=>'', 'echo'=>0)).'</ul>';
echo $nav_menu;
?>
<form method="get" id="searchform" action="/"> <input id="s" type="text" name="s" placeholder="search this site..." /> <input type="hidden" name="post_type" value="post" /></form>
<div class="clear"></div>
</nav>   

<?php $adsheader = get_option('adsheader'); if($adsheader) { echo '<div class="ads">'.$adsheader.'</div>'; } ?>