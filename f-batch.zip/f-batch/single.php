<?php get_header(); ?>
<div id="content">
<div class="postsbody">
<div class="ctn">
<div class='breadcrumbs'> <?php the_category(', ') ?> > <?php the_title(); ?> </div>
<?php if ( function_exists('yoast_breadcrumb') ) 
{yoast_breadcrumb('<p id="breadcrumbs">','</p>');} ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php wpb_set_post_views(get_the_ID()); wpb_get_post_views(get_the_ID()); ?>
<h1 class="ttl"><?php the_title(); ?></h1>
<div class="th">Released On: <?php the_time('j F Y'); ?>, Posted By : <?php the_author(); ?></div>
<?php $featured = get_option('featured'); if($featured!=='' && $featured!=='0') { if ( has_post_thumbnail() ) { ?> <div class="thm"><?php the_post_thumbnail('',array('title' => ''.get_the_title().'')); ?></div> <?php } else { } } ?>
<div class="pst">
<?php the_content(); ?>
<?php wp_link_pages( array(
	'before'      => '<div class="pl"><span class="plt">' . __( 'Video:' ) . '</span>',
	'after'       => '</div>',
	'link_before' => '<span>',
	'link_after'  => '</span>',
	) );
?>
</div>
<div class="tag"><?php the_tags( '<b>Tags:</b>',', ' ); ?></div>

<div class="shr">
<a href="#" target="_blank" class="share-btn share">
    <span class="dashicons dashicons-share"></span>
</a>
<a href="http://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank" class="share-btn twitter">
    <span class="dashicons dashicons-twitter"></span>
</a>
<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" class="share-btn google-plus">
    <span class="dashicons dashicons-googleplus"></span>
</a>
<a href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank" class="share-btn facebook">
    <span class="dashicons dashicons-facebook-alt"></span>
</a>
</div>
<div class="snip">
	<div itemscope itemtype="http://data-vocabulary.org/Review">
	<span itemprop="itemreviewed"><?php the_title(); ?></span> &#124;
	<span itemprop="reviewer">
		<span class="author vcard"><?php the_author(); ?></span>
	</span> &#124;
	<span itemprop="rating" class="rating">4.5</span></div> 
	</div>
<?php endwhile; endif; ?>
<?php get_template_part('related'); ?>
<div class="commentarea">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php echo get_post_meta($post->ID, "embed", true); ?>
<?php comments_template(); ?>
<?php endwhile; endif; ?>
</div>
</div>
</div>

<?php get_template_part('sidebar_right'); ?>
</div>
<?php get_footer(); ?>