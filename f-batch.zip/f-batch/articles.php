<style>.detpost{background:#f7f7f7;height:90px;overflow:hidden}
.episodeye{}
.episodeye h2{font-size:12px;color:#000;}
.episodeye h2 a{color:#444}</style>
<div class="vinsmoke">
<div class="thumbsmoke">
<div class="kuro">
<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); }?>
</div>
</div>
<div class="detpost">
<div class="episodeye">
<h2 class='episodeye'><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2></div>

<div class="stud">
<i class="fa fa-user"></i> Posted By :</b> <?php the_author(); ?> <br/> 
<i class="fa fa-clock-o"></i> Released on :</b> <?php the_time('F jS, Y'); ?> <br/></div>
<div class="gwspak">
<i class="fa fa-folder-open"></i> Category :</b> <?php 
foreach((get_the_category()) as $category) { 
    echo '<a href="/anime/' . $category->slug . '">' . $category->cat_name . '</a>'; 
} 
?><br><i class="fa fa-eye"></i> Views :</b> <?php $postid = get_the_ID(); echo wpb_get_post_views($postid); ?> 
</div></div></div>