<?php get_header(); ?>
<div id="content">
<div class="postsbody">
<div class="lts">
<div class="cst">
<?php if ( function_exists('yoast_breadcrumb') ) 
{yoast_breadcrumb('<p id="breadcrumbs">','</p>');} ?>
</div>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php get_template_part('content'); ?>
<?php endwhile; ?>

<!-- pagination -->
<div class="pagination">
<?php pagenavi(); ?>
</div>
</div>
<?php else : ?>
		<h2 class="center">No posts found. Try a different search?</h2>
</div>
	<?php endif; ?>
</div>

<?php get_template_part('sidebar_right'); ?>
</div>

<?php get_footer(); ?>