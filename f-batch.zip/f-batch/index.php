<?php get_header(); ?>
<div id="content">
<div class="postsbody">
<div class="lts">
<div class="cst">
<center><h3>Info</h3></center>
<h1>1.) ini untuk percobaan</h1>
<h1>2.) ini untuk belajar</h1>
<h1>3.) ini untuk permulaan</h1>
<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=100%
 style='width:100%;border-collapse:collapse'>
 <tr style='height:.2in'>
  <td width=67 valign=top style='width:.7in;border-top:solid black 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:none;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
  <td width=498 valign=top style='width:373.2pt;border-top:solid black 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:none;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'>Info</span></u></p>
  </td>
  <td width=498 valign=top style='width:373.2pt;border:solid black 1.0pt;
  border-left:none;padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
 </tr>
 <tr style='height:.2in'>
  <td width=67 valign=top style='width:.7in;border:none;border-bottom:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
  <td width=498 valign=top style='width:373.2pt;border:none;border-bottom:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
  <td width=498 valign=top style='width:373.2pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
 </tr>
 <tr style='height:.2in'>
  <td width=67 valign=top style='width:.7in;border:none;border-bottom:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
  <td width=498 valign=top style='width:373.2pt;border:none;border-bottom:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
  <td width=498 valign=top style='width:373.2pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
 </tr>
 <tr style='height:.2in'>
  <td width=67 valign=top style='width:.7in;border:none;border-bottom:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
  <td width=498 valign=top style='width:373.2pt;border:none;border-bottom:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
  <td width=498 valign=top style='width:373.2pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0in 1.5pt 0in 1.5pt;height:.2in'>
  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal;text-autospace:none'><u><span
  style='font-size:11.0pt;font-family:"Calibri","sans-serif";color:black'><span
   style='text-decoration:none'>&nbsp;</span></span></u></p>
  </td>
 </tr>
</table>

</div>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php get_template_part('content'); ?>
<?php endwhile; ?>
<div class="clear"></div>
<!-- pagination -->
<div class="pagination">
<?php pagenavi(); ?>
</div>
<?php else : ?>
<!-- No posts found -->
<?php endif; ?>
</div>
</div>

<?php get_template_part('sidebar_right'); ?>
</div>

<?php get_footer(); ?>