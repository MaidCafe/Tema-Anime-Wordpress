<?php get_header(); ?>
<div class="container">
<div class="alert alert-info">
<p>We welcome you to provide feedback at <a href="irc://irc.rizon.net/nyaa-dev">#nyaa-dev@irc.rizon.net</a></p>
<p>Our GitHub: <a href="https://github.com/nyaadevs" target="_blank">https://github.com/nyaadevs</a> - creating <a href="https://github.com/nyaadevs/nyaa/issues">issues</a> for features and faults is recommendable!</p>
</div>
<div class="table-responsive">
<table class="table table-bordered table-hover table-striped torrent-list">
<thead>
<tr>
<th class="hdr-category text-center" style="width:80px;">
<div>Category</div>
</th>
<th class="hdr-name" style="width:auto;">
<div>Name</div>
</th>
<th class="hdr-comments sorting text-center" title="Comments" style="width:50px;">
<a href="/?s=comments&amp;o=desc"></a>
<i class="fa fa-comments-o"></i>
</th>
<th class="hdr-link text-center" style="width:70px;">
<div>Link</div>
</th>
<th class="hdr-size sorting text-center" style="width:100px;">
<a href="/?s=size&amp;o=desc"></a>
<div>Size</div>
</th>
<th class="hdr-date sorting_desc text-center" title="In UTC" style="width:140px;">
<a href="/?s=id&amp;o=asc"></a>
<div>Date</div>
</th>
<th class="hdr-seeders sorting text-center" title="Seeders" style="width:50px;">
<a href="/?s=seeders&amp;o=desc"></a>
<i class="fa fa-arrow-up" aria-hidden="true"></i>
</th>
<th class="hdr-leechers sorting text-center" title="Leechers" style="width:50px;">
<a href="/?s=leechers&amp;o=desc"></a>
<i class="fa fa-arrow-down" aria-hidden="true"></i>
</th>
<th class="hdr-downloads sorting text-center" title="Completed downloads" style="width:50px;">
<a href="/?s=downloads&amp;o=desc"></a>
<i class="fa fa-check" aria-hidden="true"></i>
</th>
</tr>
</thead>
<tbody>

<?php if ( have_posts() ) : ?>
<?php
if( is_home() ){
$paged = (get_query_var('paged')) ? get_query_var('paged') : 0;
query_posts( array('post_type'=>array(
'post','anime', 'batch' ),'paged'=>$paged ) );
}
?>
<?php while ( have_posts() ) : the_post(); ?>
<?php get_template_part('articles'); ?>
<?php endwhile; endif; ?>

</tbody>
</table>
</div>

<div class="center">
<nav>
<ul class="pagination">
<li><a href='?pg=$link'>&laquo;</a></li>
<li class='disabled'><a href='#'>&laquo;</a></li>
<li class='active'><a href='#'>$i<span class='sr-only'>(current)</span></a></li>
<li><a href='?pg=$i'>$i</a></li>
<li><a href='?pg=$link'>&raquo;</a></li>
<li class='disabled'><a href='#'>&raquo;</a></li>
</ul>
</nav>
</div>
</div>  
<?php get_footer(); ?>