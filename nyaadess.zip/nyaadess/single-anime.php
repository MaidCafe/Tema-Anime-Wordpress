<?php
/*
Template Name: Info Anime
*/
get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="container">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">
<?php the_title(); ?>
</h3>
</div>
<div class="panel-body">
<div class="row">
<div class="col-md-1">Category:</div>
<div class="col-md-5"><?php echo get_post_meta($post->ID, 'dbt_cat_nime', true);?></div>
<div class="col-md-1">Status:</div>
<div class="col-md-5" ><?php echo get_the_term_list( $post->ID, 'status', '', ', ', '' ); ?></div>
</div>
<div class="row">
<div class="col-md-1">Genre:</div>
<div class="col-md-5"><?php echo get_the_term_list( $post->ID, 'genre', '', ', ', '' ); ?></div>
<div class="col-md-1">Type:</div>
<div class="col-md-5"><span style="color: green;"><?php echo get_the_term_list( $post->ID, 'type', '', '' ); ?></span></div>
</div>
<div class="row">
<div class="col-md-1">Episode:</div>
<div class="col-md-5"><?php echo get_the_term_list( $post->ID, 'episodes', '', '' ); ?></a>
</div>
<div class="col-md-1">Season:</div>
<div class="col-md-5"><span style="color: red;"><?php echo get_the_term_list( $post->ID, 'seasons', '', ', ', '' ); ?></span></div>
</div>
<div class="row">
<div class="col-md-1">Rating:</div>
<div class="col-md-5"><?php echo get_the_term_list( $post->ID, 'rating', '', ', ', '' ); ?></div>
<div class="col-md-1">Duration:</div>
<div class="col-md-5"><?php echo get_the_term_list( $post->ID, 'duration', '', '' ); ?></div>
</div>
<div class="row">
<div class="col-md-offset-6 col-md-1">Link site:</div>
<div class="col-md-5"><kbd><?php the_permalink(); ?></kbd></div>
</div>
</div> 
<div class="panel-footer clearfix">

</div>
</div> 

<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">
Sinopsis
</h3>
</div>
<div class="panel-body">
<div class="row">
<img class="col-md-3" src="https://animesearch.net/wp-content/uploads/2017/06/84417.jpg">
<div class="col-md-8"><?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?></div>
</div>
</div> 
<div class="panel-footer clearfix">
</div>
</div> 

<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Episode list</h3>
</div>
<div class="torrent-file-list panel-body">
<ul>
    <?php endwhile; endif; ?>
<?php global $post; ?>
<?php $slug = get_post( $post->ID, "anime", true )->post_name; ?>
<?php $recent = new WP_Query("category_name=$slug&showposts=100"); while($recent->have_posts()) : $recent->the_post(); ?>
<li></li>

<li><i class="fa fa-file"></i><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><span class="file-size">(<?php echo get_post_meta($post->ID, 'dbt_cat_nime', true);?>)</span></li>
<?php endwhile; ?>
<?php wp_reset_query(); ?>

<?php
$valky = get_the_category();
    $args = array(
        'post_type' => 'batch',
        'post__not_in' => array( get_the_ID() ),
        'posts_per_page' => 1,
        'category'     => $valky,
        'meta_query' => array(
                    array(
                    
                        )
                    )
    );
    $query = new WP_Query( $args );

?>  
<?php if( $query->have_posts() ) : while( $query->have_posts() ) : $query->the_post(); ?>
<li><i class="fa fa-file"></i><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><span class="file-size">(<?php echo get_post_meta($post->ID, 'dbt_cat_nime', true);?>)</span></li>
<?php endwhile; endif; wp_reset_postdata(); ?>
</ul>
</div>
</div> 

</div> 
<?php get_footer(); ?>