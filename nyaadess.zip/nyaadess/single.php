<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="container">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">
<?php the_title(); ?>
</h3>
</div>
<div class="panel-body">
<div class="row">
<div class="col-md-1">Category:</div>
<div class="col-md-5">
<?php
$cate = array(

    "1_1"=>"<a href='/?c=1_0'>Anime</a> - <a href='/?c=1_1'>Anime Music Video</a>",
    "1_2"=>"<a href='/?c=1_0'>Anime</a> - <a href='/?c=1_2'>English-translated</a>",
    "1_3"=>"<a href='/?c=1_0'>Anime</a> - <a href='/?c=1_3'>Indonesia-translated</a>",
    "1_4"=>"<a href='/?c=1_0'>Anime</a> - <a href='/?c=1_4'>Raw</a>",

    "2_1"=>"<a href='/?c=2_0'>Audio</a> - <a href='/?c=2_1'>Lossless</a>",
    "2_2"=>"<a href='/?c=2_0'>Audio</a> - <a href='/?c=2_2'>Lossy</a>",

    "3_1"=>"<a href='/?c=3_0'>Literature</a> - <a href='/?c=3_1'>English-translated</a>",
    "3_2"=>"<a href='/?c=3_0'>Literature</a> - <a href='/?c=3_2'>Indonesia-translated</a>",
    "3_3"=>"<a href='/?c=3_0'>Literature</a> - <a href='/?c=3_3'>Raw</a>",

    "4_1"=>"<a href='/?c=4_0'>Live Action</a> - <a href='/?c=4_1'>English-translated</a>",
    "4_2"=>"<a href='/?c=4_0'>Live Action</a> - <a href='/?c=4_2'>Idol/Promotional Video</a>",
    "4_3"=>"<a href='/?c=4_0'>Live Action</a> - <a href='/?c=4_3'>Indonesia-translated</a>",
    "4_4"=>"<a href='/?c=4_0'>Live Action</a> - <a href='/?c=4_4'>Raw</a>",

    "5_1"=>"<a href='/?c=5_0'>Pictures</a> - <a href='/?c=5_1'>Graphics</a>",
    "5_2"=>"<a href='/?c=5_0'>Pictures</a> - <a href='/?c=5_2'>Photos</a>",

    "6_1"=>"<a href='/?c=6_0'>Software</a> - <a href='/?c=6_1'>Applications</a>",
    "6_2"=>"<a href='/?c=6_0'>Software</a> - <a href='/?c=6_2'>Games</a>"
    );
print_r($cate[$cat]) ;
?>

</div>
<div class="col-md-1">Date:</div>
<div class="col-md-5" ><?php echo $times ; ?></div>
</div>
<div class="row">
<div class="col-md-1">Submitter:</div>
<div class="col-md-5">
<a class="text-default" href="/user/desyo"><?php echo $uploader ; ?></a> </div>
<div class="col-md-1">Coment:</div>
<div class="col-md-5"><span style="color: green;">12</span></div>
</div>
<div class="row">
<div class="col-md-1">Information:</div>
<div class="col-md-5"><?php echo $info ; ?></a>
</div>
<div class="col-md-1">Report:</div>
<div class="col-md-5"><span style="color: red;">4</span></div>
</div>
<div class="row">
<div class="col-md-1">File size:</div>
<div class="col-md-5"><?php echo $size ; ?></div>
<div class="col-md-1">View:</div>
<div class="col-md-5">14</div>
</div>
<div class="row">
<div class="col-md-offset-6 col-md-1">Link site:</div>
<div class="col-md-5"><kbd>https://<?php echo $id; ?></kbd></div>
</div>
</div> 
<div class="panel-footer clearfix">
<a href="<?php echo $link1 ; ?>"><i class="fa fa-download fa-fw"></i>Download Torrent</a> or <a href="<?php echo $link2 ; ?>"><i class="fa fa-magnet fa-fw"></i>Magnet</a>
or
<a href="<?php echo $link1 ; ?>"><i class="fa fa-download fa-fw"></i>Download Torrent</a> or <a href="<?php echo $link2 ; ?>"><i class="fa fa-magnet fa-fw"></i>Magnet</a>
<button type="button" class="btn btn-xs btn-danger pull-right" data-toggle="modal" data-target="#reportModal">
Report
</button>
</div>
</div> 
<div class="panel panel-default">
<div class="panel-body" id="torrent-description"><?php the_content(); ?></div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">File list</h3>
</div>
<div class="torrent-file-list panel-body">
<ul>
<li><i class="fa fa-file"></i><?php echo $title ; ?> <span class="file-size">(<?php echo $size ; ?>)</span></li>
</ul>
</div>
</div> 
<?php endwhile; endif; ?>


<div id="comments" class="panel panel-default">

<?php if (have_comments() ) : ?>
<div class="panel-heading">
<h3 class="panel-title">
<?php comments_number('No Comments', 'One Comments', '% Comments'); ?>
<?php wp_list_comments('callback=nyaa_comments') ;?>
</h3>
</div>
<div class="panel panel-default comment-panel" id="com-1">
<div class="panel-body">
<div class="col-md-2">
<p>
<a class="text-default" href="/user/handriand">handriand</a>
(uploader)
</p>
<p><img class="avatar" src="https://www.gravatar.com/avatar/00a6a203ec86c3667913dec3e663123e?d=https%3A%2F%2Fnyaa.si%2Fstatic%2Fimg%2Favatar%2Fdefault.png&amp;s=120" alt="User"></p>
</div>
<div class="col-md-10">
<div class="row">
<a href="#com-1"><small data-timestamp-swap data-timestamp="1497028928">2017-06-09 17:22 UTC</small></a>
<form class="delete-comment-form" action="/view/929582/comment/2009/delete" method="POST">
<button name="submit" type="submit" class="btn btn-danger btn-xs" title="Delete">Delete</button>
</form>
</div>
<div class="row">
<div markdown-text class="comment-content" id="torrent-comment2009">ty for uploading</div>
</div>
</div>
</div>
</div>
<?php endif; ?>

<?php comments_template(); ?>

</div>
<div class="modal fade" id="reportModal" tabindex="-1" role="dialog" aria-labelledby="reportModalLabel">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">Report torrent #929582</h4>
</div>
<div class="modal-body">
<form method="POST" action="https://nyaa.si/view/929582/submit_report">
<input id="csrf_token" name="csrf_token" type="hidden" value="IjM5ZjFhMTU0NDQ1NGQ1YTViODRjNTc1N2M2YWE4MDExMjkwMGM2ZGUi.DBxqwQ.WLydgNmr08ijkeyLvZxRrPY65GM">
<div class="form-group">
<label class="control-label" for="reason">Report reason</label>
<textarea class="form-control" id="reason" maxlength="255" name="reason" title=""></textarea>
</div>
<div style="float: right;">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="submit" class="btn btn-danger">Report</button>
</div>
</form>
</div>
<div class="modal-footer" style="border-top: none;">
</div>
</div>
</div>
</div>
<script type="text/javascript">
	// Focus the report text field once the modal is opened.
	$('#reportModal').on('shown.bs.modal', function () {
		$('#reason').focus();
	});
</script>
</div> 
<?php get_footer(); ?>